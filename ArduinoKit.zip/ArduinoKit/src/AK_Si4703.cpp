#include "Arduino.h"
#include "AK_Si4703.h"
#include "Wire.h"
//SEEKSENS - 0=More Stations, 2=Fewer Stations
#define SEEKSENS 0
//#define DEBUG 1
//#undef DEBUG
#define DEBUGRDSBASIC 0
//int volatile intInterrupt;

AK_Si4703::AK_Si4703(int resetPin, int sdioPin, int sclkPin)
{
  _resetPin = resetPin;
  _sdioPin = sdioPin;
  _sclkPin = sclkPin;
}

void AK_Si4703::intFunc() {
  byte bytSAME;
  byte bytASQ;
  #if DEBUG
    Serial.println("Interrupt activated.");
  #endif
  #if DEBUG
    Serial.print("Status byte=0x");
  #endif

}
  
  
void AK_Si4703::powerOn()
{
    si4703_init();
    //pinMode(2, INPUT);
    //attachInterrupt(0, AK_Si4703::intFunc, FALLING);
}

void AK_Si4703::setChannel(int channel)
{
  //Freq(MHz) = 0.200(in USA) * Channel + 87.5MHz
  //97.3 = 0.2 * Chan + 87.5
  //9.8 / 0.2 = 49
  //channel = ((10 * channel) / 5) + 875;
  //Multiply by 10 to eliminate decimal points, and divide by 5 is analagous to * 0.2, and finally add 875 (87.5 * 10) for base freq.
  int newChannel = (((channel - 875) * 5) / 10);
  /* - Old UK Method of selecting channel
  int newChannel = channel * 10; //973 * 10 = 9730
  newChannel -= 8750; //9730 - 8750 = 980
  newChannel /= 10; //980 / 10 = 98
*/

  //These steps come from AN230 page 20 rev 0.5
  readRegisters();
  si4703_registers[CHANNEL] &= 0xFE00; //Clear out the channel bits
  si4703_registers[CHANNEL] |= newChannel; //Mask in the new channel
  si4703_registers[CHANNEL] |= (1<<TUNE); //Set the TUNE bit to start
  updateRegisters();

  //delay(60); //Wait 60ms - you can use or skip this delay

  //Poll to see if STC is set
  while(1) {
    readRegisters();
    if( (si4703_registers[STATUSRSSI] & (1<<STC)) != 0) break; //Tuning complete!
  }

  readRegisters();
  si4703_registers[CHANNEL] &= ~(1<<TUNE); //Clear the tune after a tune has completed
  updateRegisters();

  //Wait for the si4703 to clear the STC as well
  while(1) {
    readRegisters();
    if( (si4703_registers[STATUSRSSI] & (1<<STC)) == 0) break; //Tuning complete!
  }
}

int AK_Si4703::seekUp()
{
	return seek(SEEK_UP);
}

int AK_Si4703::seekDown()
{
	return seek(SEEK_DOWN);
}

void AK_Si4703::setVolume(int volume)
{
  readRegisters(); //Read the current register set
  if(volume < 0) volume = 0;
  if (volume > 15) volume = 15;
  si4703_registers[SYSCONFIG2] &= 0xFFF0; //Clear volume bits
  si4703_registers[SYSCONFIG2] |= volume; //Set new volume
  updateRegisters(); //Update
}



int AK_Si4703::updateStatus()
{
	int err = readRegisters();
	if (err < 0)
		return(err);
}

void AK_Si4703::startTick(uint16_t ticktime)
{
  statusTick.attach_ms(ticktime, std::bind(&AK_Si4703::tickISR, this));
}
void AK_Si4703::stopTick()
{
  statusTick.detach();
}

/*****************************************************************
 * Low level functions for use in real time operation
 * These functions perform a minimal effort to kick off an event_callback
 *
 ****************************************************************/ 

/*****************************************************************
 * checkStatus - read just the status register and return
 ****************************************************************/ 
uint16_t AK_Si4703::checkStatus()
{
  uint16_t status;
    Wire.requestFrom(SI4703, 2); //Just read address 0A

  while (Wire.available() < 2)
  {
  }
  status = Wire.read() << 8;
  status |= Wire.read();
  si4703_registers[0x0A] = status;
  return status;
}


/*****************************************************************
 * checkStatus - read status registers 0x0A to 0x0F and return
 *   returns the status register to the return value
 *   the regosters B to F are stored in the struct passed in
 ****************************************************************/
uint16_t AK_Si4703::checkStatus(rdsData_t *rdsABCD)
{
  uint16_t status;
  uint16_t readCount = 12; //Just read address 0A through 0F
	  
  Wire.requestFrom(SI4703, readCount);

  while (Wire.available() < readCount)
  {
  }
  status = Wire.read() << 8;
  status |= Wire.read();
  si4703_registers[0x0A] = status;
  for(int x = 0x0B ; ; x++) { //Read in the rest of the status bytes
    si4703_registers[x] = Wire.read() << 8;
    si4703_registers[x] |= Wire.read();
    if(x == 0x0F) break; //We're done!
  }
  rdsABCD->BLerrs = si4703_registers[0x0B];
  rdsABCD->rds_A = si4703_registers[0x0C];
  rdsABCD->rds_B = si4703_registers[0x0D];
  rdsABCD->rds_C = si4703_registers[0x0E];
  rdsABCD->rds_D = si4703_registers[0x0F];  

  if (status & 0x8800 == 0x8800)	//rdsr set and sync bit set so data is available
	_rdsAvailable = true;
  else
    _rdsAvailable = false;
	  
  if (status & 0x4000)	// seek complete set
	_seekComplete = true;
  else
    _seekComplete = false;
  return status;
}


void AK_Si4703::enableRDS()
{
  readRegisters();
  uint16_t pwrcfg = si4703_registers[POWERCFG];
  uint16_t syscfg1 = si4703_registers[SYSCONFIG1];
  pwrcfg |= 0x0800;	// set bit 11, RDS verbose mode
  syscfg1 |= 0x1000;	// set bit 12, RDS enable
  si4703_registers[SYSCONFIG1] = syscfg1;
  updateRegisters(); 	// for now ignore return val
}

/****************************************************************
 * start and stop seek
 * need to wait for the STC bit in the status to confirm the seek
 * seekStart sets the seek bit, seekStop clears it
 ****************************************************************/
void AK_Si4703::seekStart(byte seekDirection) {
  resetRDS();
  readRegisters();
  //Set seek mode wrap bit
  //si4703_registers[POWERCFG] |= (1<<SKMODE); //Disallow wrap - if you disallow wrap, you may want to tune to 87.5 first
  si4703_registers[POWERCFG] &= ~(1<<SKMODE); //Allow wrap
  if(seekDirection == SEEK_DOWN) si4703_registers[POWERCFG] &= ~(1<<SEEKUP); //Seek down is the default upon reset
  else si4703_registers[POWERCFG] |= 1<<SEEKUP; //Set the bit to seek up

  si4703_registers[POWERCFG] |= (1<<SEEK); //Start seek
  updateRegisters(); //Seeking will now start. We need to send all registers, I think
}	

void AK_Si4703::seekStop() {
  resetRDS();
  readRegisters();
//    int valueSFBL = si4703_registers[STATUSRSSI] & (1<<SFBL); //Store the value of SFBL
  si4703_registers[POWERCFG] &= ~(1<<SEEK); //Clear the seek bit after seek has completed
  updateRegisters(); //Seeking will now start. We need to send all registers, I think
}	

void AK_Si4703::setChannelStart(int channel)
{
	int newChannel = (((channel - 875) * 5) / 10);

  //These steps come from AN230 page 20 rev 0.5
  // assume we have already done readRegisters();
  si4703_registers[CHANNEL] &= 0xFE00; //Clear out the channel bits
  si4703_registers[CHANNEL] |= newChannel; //Mask in the new channel
  si4703_registers[CHANNEL] |= (1<<TUNE); //Set the TUNE bit to start
  updateRegisters();
  resetRDS();
}

/***********************************************************
* void AK_Si4703::updateRDS(long timeout)
* Called immediately after checkStatus
* When the status bit (reg0A) is set, RDS data is ready
* See SiLabs AN230 and AN243 for details on RDS
* in verbose mode we get the following
* RDSA (reg0B) has rdsPIcode which is a unique station ID with info on alternate stations
* RDSB (reg0C) has {rdsGroup[3:0],rdsVersion,Traffic,PTY[4:0],Unused[4:0]}
*				rdsGroup: see later
*				rdsVersion
*				Traffic
*				PTYcode: tells what type of music is being played (Classical, etc)
************************************************************/

void AK_Si4703::updateRDS(long timeout)
{
	long start_time = millis();
	uint8_t next = rdsState;
	uint16_t pwrcfg;
	uint16_t syscfg1;
	uint16_t rdsStatus;
	uint16_t blera;		// error for RDSA
	uint16_t blerb;		// error for RDSB
	uint16_t blerc;		// error for RDSC
	uint16_t blerd;		// error for RDSD	
	uint16_t grouptype;	// RDSB >> 11
	bool error = false;
	bool rdsDataRdy = false;
	bool done = false;

	while (!done)  // get as far as we can
	{
//		if (~_rdsAvailable)		// has ISR already read the registers?
//			checkStatus(); //return; //readRegisters();
		rdsStatus = si4703_registers[STATUSRSSI] & 0x8E00;
		pwrcfg = si4703_registers[POWERCFG];
		syscfg1 = si4703_registers[SYSCONFIG1];
		rdsDataRdy = ((rdsStatus & 0x8000) != 0); //RDSR and RDS sync both set
		blera = (rdsStatus & 0x0600)  >> 9; // bits 10:9
		blerb = (si4703_registers[READCHAN] & 0xC000) >> 14;
		blerc = (si4703_registers[READCHAN] & 0x3000) >> 12;
		blerd = (si4703_registers[READCHAN] & 0x0C00) >> 10;
		grouptype = (si4703_registers[RDSB] & 0xF800) >> 11; 	//bits 15-11
		rdsIndex = 4*(si4703_registers[RDSB] & 0x000F);

		switch (rdsState)
		{
			case RDSINIT:
			#ifdef DEBUG
				Serial.print("state = RDSINIT: pwrcfg was 0x");
				Serial.print(pwrcfg, HEX);
				si4703_registers[POWERCFG] = pwrcfg;
				Serial.print(": syscfg1 was 0x");
				Serial.println(syscfg1,HEX);
			#endif
				pwrcfg |= 0x0800;	// set bit 11, RDS verbose mode
				syscfg1 |= 0x1000;	// set bit 12, RDS enable
				si4703_registers[SYSCONFIG1] = syscfg1;
				rdsIndexMax = 0;
				updateRegisters(); 	// for now ignore return val
				next = RDSIDLE;
			#ifdef DEBUG
				Serial.println();
			#endif
				break;
			
			case RDSIDLE:
			#ifdef DEBUG
				Serial.print("state = RDSIDLE: ");
			#endif
				uint16_t rdsPTYtemp;
				if (rdsDataRdy)
				{
					// already read the registers
					#ifdef DEBUG
					Serial.print("RDS data ready ");
					#endif
					if (blera < 2)
					{
						rdsPIcode = si4703_registers[RDSA];
					}
					else
					{
					#ifdef DEBUG
						Serial.print("blera > 2");
					#endif
					}
				}
				
				if (blerb > 1)
				{
					RTsync = false;
					CLKsync = false;
					#ifdef DEBUG
					Serial.print("blerb = " + String(blerb));
					#endif
			
					next = RDSDONE;
				}
				else
				{
					if ((grouptype & 0x01) != 0) // group type B has more PI code
					{
						//update PI code
						#ifdef DEBUG
						Serial.print("Group B");
						#endif
					}
				rdsPTYtemp = (si4703_registers[RDSB] & 0x03E0) >> 5;	//bits 9-5
				rdsPTYgood = false;
				// gotta get 6 in a row that match and have no errors in blerb
				if (blerb == 0)
				{
				  rdsPTYcode[5] = rdsPTYcode[4];
				  rdsPTYcode[4] = rdsPTYcode[3];
				  rdsPTYcode[3] = rdsPTYcode[2];
				  rdsPTYcode[2] = rdsPTYcode[1];
				  rdsPTYcode[1] = rdsPTYtemp;
				  for (int i = 1; i < 6; i++)
				  {
					if (rdsPTYcode[i] != rdsPTYtemp)
					{
					  rdsPTYgood = false;
					  break;
					}
					rdsPTYgood = true;
				  }
				  if (rdsPTYgood)
				    rdsPTYcode[0] = rdsPTYtemp;	  
				}
/*				else if ( (rdsPTYcode[3] == rdsPTYcode[2]) && (rdsPTYcode[1] == rdsPTYcode[2]) )
				{
					rdsPTYgood = true;
					rdsPTYcode[0] = rdsPTYtemp;
				}
*/				
				#ifdef DEBUG
					Serial.print("PTY code = " + String(rdsPTYcode[0]));
				#endif
					next = RDSGRPDEC;
				}
			#ifdef DEBUG
				Serial.println();
			#endif
				break;

			case RDSGRPDEC:
				#ifdef DEBUG
				Serial.print("state = RDSGRPDEC: ");
				Serial.print("Group type " + getGroupType(grouptype) + ": ");
				#endif

				//	station = (si4703_registers[READCHAN] & 0x3FF);
				switch (grouptype)
				{
					case RDSRTA:
					case RDSRTB:
						next = RDSRADTXTSYNC;
					break;
						
					case RDSCLK:
						next = RDSRADIOTIME;
					break;
				
					case RDSBTA:
					case RDSBTB:
					default:
						next = RDSDONE; // later create a case to process basic data
					break;
				} // switch grptype
			#ifdef DEBUG
				Serial.println();
			#endif
				break;  // state

			case RDSRADTXTSYNC:
			#ifdef DEBUG
				Serial.print("state = RDSRADTXTSYNC: ");
			#endif

				rdsRTindex = rdsIndex;
				if (RTsync)
				{
					if (rdsRTindex == 0)
					{
						strRDSText = strRDSTemp;
						strRDSTemp = "";
						for (int i = 0; i < 64; i++)
							rdsBuffer[i] = 0;
						rdsIndexMax = 0;
						rdsIndex = 0;
						rdsRTindex = 0;
					}
					next = RDSRADIOTEXT;
				}
				else
				{
					if (rdsRTindex == 0)
						next = RDSRADIOTEXT;
					else
						next = RDSDONE;
				}
			#ifdef DEBUG
				Serial.println();
			#endif
				break;
				
			case RDSRADIOTEXT:
			#ifdef DEBUG
				Serial.print("state = RDSRADIOTEXT: ");
			#endif
				if (grouptype == RDSRTA) // grouptype 2A
				{
					if (blerc < 3)
					{
					#ifdef DEBUG
						Serial.print("RDSB = " + String(si4703_registers[RDSB]));
						Serial.println(": Radio Text: Group " + getGroupType(grouptype));
						Serial.print("RDSC:RDSD = " + String(si4703_registers[RDSC], HEX));
						Serial.println(si4703_registers[RDSD], HEX);
				#	endif						
						rdsBuffer[rdsRTindex++] = (char)((si4703_registers[RDSC] & 0xFF00) >> 8);
						rdsBuffer[rdsRTindex++] = (char)((si4703_registers[RDSC] & 0x00FF)     );
					}
					else
					{
						RTsync = false;
						next = RDSDONE;
					}
				}
				if (blerd < 3)
				{
					rdsBuffer[rdsRTindex++] = (char)((si4703_registers[RDSD] & 0xFF00) >> 8);
					rdsBuffer[rdsRTindex] = (char)((si4703_registers[RDSD] & 0x00FF)     );
					RTsync = true; // got good data
				}
				else
					RTsync = false;
				
				if (rdsIndex > (rdsIndexMax-1))
					rdsIndexMax = rdsIndex;
				rdsBuffer[rdsIndexMax + 4] = '\0';
				for (int i = 0; i < rdsIndexMax+4; i++)
					if (rdsBuffer[i] == 0x0D)
					{
						rdsBuffer[i] = '\0';
						Serial.print("At the end, Index = ");
						Serial.println(rdsIndexMax);
						char s[100];
						for (int i = 0; i < 100; i++)
							s[i] = 0;
						for (int i = 0; i < rdsIndexMax; i++)
							sprintf(s, "%s%c",s, rdsBuffer[i]);
						Serial.println(rdsBuffer);
						Serial.println(s);
						Serial.println("-------------------------");
					}
				strRDSTemp = String(rdsBuffer);
				#ifdef DEBUG
					Serial.print("Index = " + String(rdsIndex) + ": RDStext = ");
					Serial.println(strRDSTemp);
					Serial.println("-------------------------");
				#endif
				next = RDSDONE;
				#ifdef DEBUG
					Serial.println();
				#endif
				break;
					
			case RDSDONE:
			#ifdef DEBUG
				Serial.println("state = RDSDONE: ");
			#endif
				next = RDSIDLE;
				done = true;
				_rdsAvailable = false;

				break;
			default:
				next = RDSIDLE;
				break;
		} // end switch
		rdsState = next;
				// if time, keep going
				if (millis() - start_time < timeout)
					done = false;
				else
					done = true;
	} // end while
}

String AK_Si4703::getRDSProgtype()
{
//	if (rdsPTYgood)
		return(rdsPTY[rdsPTYcode[0]]);
//	else
//		return("");
}


void AK_Si4703::tickISR()
{
	checkStatus();
}



//To get the Si4703 inito 2-wire mode, SEN needs to be high and SDIO needs to be low after a reset
//The breakout board has SEN pulled high, but also has SDIO pulled high. Therefore, after a normal power up
//The Si4703 will be in an unknown state. RST must be controlled
void AK_Si4703::si4703_init() 
{
  pinMode(_resetPin, OUTPUT);
  pinMode(_sdioPin, OUTPUT); //SDIO is connected to A4 for I2C
  digitalWrite(_sdioPin, LOW); //A low SDIO indicates a 2-wire interface
  digitalWrite(_resetPin, LOW); //Put Si4703 into reset
  delay(1); //Some delays while we allow pins to settle
  digitalWrite(_resetPin, HIGH); //Bring Si4703 out of reset with SDIO set to low and SEN pulled high with on-board resistor
  //pinMode(_resetPin, INPUT); //Change to input to allow onboard resistor (You must add!) to pull reset high, disabling reset signal.
  delay(1); //Allow Si4703 to come out of reset

  connect();
  Wire.begin(_sdioPin, _sclkPin); //Now that the unit is reset and I2C inteface mode, we need to begin I2C

  //Read the current register set
  readRegisters();
  si4703_registers[0x07] = 0x8100; //Enable the oscillator, from AN230 page 9, rev 0.61 (works)
  updateRegisters(); //Update

  delay(500); //Wait for clock to settle - from AN230 page 9

  readRegisters(); //Read the current register set
  si4703_registers[POWERCFG] = 0x4001; //Enable the IC
  //  si4703_registers[POWERCFG] |= (1<<SMUTE) | (1<<DMUTE); //Disable Mute, disable softmute
  si4703_registers[SYSCONFIG1] |= (1<<RDS); //Enable RDS

  si4703_registers[SYSCONFIG1] |= (1<<DE); //50kHz Europe setup
  //si4703_registers[SYSCONFIG2] |= (1<<SPACE0); //100kHz channel spacing for Europe

  si4703_registers[SYSCONFIG2] &= 0xFFF0; //Clear volume bits
  si4703_registers[SYSCONFIG2] |= 0x0001; //Set volume to lowest
  
  #if SEEKSENS == 1
    si4703_registers[SYSCONFIG2] &= 0x00FF; //Clear SEEKTH bits
    si4703_registers[SYSCONFIG2] |= 0x1900; //Set SEEKTH to recommended settings
    si4703_registers[0x6] &= 0xFF00; //Clear SKSNR & SKCNT bits
    si4703_registers[0x6] |= 0x0048; //Set SKSNR & SKCNT to recommended settings
  #endif
  #if SEEKSENS == 0
    si4703_registers[SYSCONFIG2] &= 0x00FF; //Clear SEEKTH bits
    si4703_registers[SYSCONFIG2] |= 0x0C00; //Set SEEKTH to recommended settings
    si4703_registers[0x6] &= 0xFF00; //Clear SKSNR & SKCNT bits
    si4703_registers[0x6] |= 0x0048; //Set SKSNR & SKCNT to recommended settings
  #endif
  #if SEEKSENS == 2
      si4703_registers[SYSCONFIG2] &= 0x00FF; //Clear SEEKTH bits
    si4703_registers[SYSCONFIG2] |= 0x0C00; //Set SEEKTH to recommended settings
    si4703_registers[0x6] &= 0xFF00; //Clear SKSNR & SKCNT bits
    si4703_registers[0x6] |= 0x007F; //Set SKSNR & SKCNT to recommended settings
  #endif
  updateRegisters(); //Update

  delay(110); //Max powerup time, from datasheet page 13
}

//Read the entire register control set from 0x00 to 0x0F
int AK_Si4703::readRegisters(){
	bool done = false;
	int startTime = millis();
  //Si4703 begins reading from register upper register of 0x0A and reads to 0x0F, then loops to 0x00.
  Wire.requestFrom(SI4703, 32); //We want to read the entire register set from 0x0A to 0x09 = 32 bytes.

  //while(Wire.available() < 32) ; //Wait for 16 words/32 bytes to come back from slave I2C device
  while (!done)
  {
	  if (Wire.available() == 32)
		  done = true;
	  else if ( (millis() - startTime) > 60)	// typical is < 5ms
	  {
		  done = true;
		  return(-1);
	  }
  }
	//Serial.println("Took " + String((millis() - startTime)) + "ms to read registers");
	
  //Remember, register 0x0A comes in first so we have to shuffle the array around a bit
  for(int x = 0x0A ; ; x++) { //Read in these 32 bytes
    if(x == 0x10) x = 0; //Loop back to zero
    si4703_registers[x] = Wire.read() << 8;
    si4703_registers[x] |= Wire.read();
    if(x == 0x09) break; //We're done!
  }
  return(-1);
}

//Write the current 9 control registers (0x02 to 0x07) to the Si4703
//It's a little weird, you don't write an I2C address
//The Si4703 assumes you are writing to 0x02 first, then increments
byte AK_Si4703::updateRegisters() {

  Wire.beginTransmission(SI4703);
  //A write command automatically begins with register 0x02 so no need to send a write-to address
  //First we send the 0x02 to 0x07 control registers
  //In general, we should not write to registers 0x08 and 0x09
  for(int regSpot = 0x02 ; regSpot < 0x08 ; regSpot++) {
    byte high_byte = si4703_registers[regSpot] >> 8;
    byte low_byte = si4703_registers[regSpot] & 0x00FF;

    Wire.write(high_byte); //Upper 8 bits
    Wire.write(low_byte); //Lower 8 bits
  }

  //End this transmission
  byte ack = Wire.endTransmission();
  if(ack != 0) { //We have a problem! 
    return(FAIL);
  }

  return(SUCCESS);
}


//Seeks out the next available station
//Returns the freq if it made it
//Returns zero if failed
int AK_Si4703::seek(byte seekDirection){
  resetRDS();
  readRegisters();
  //Set seek mode wrap bit
  //si4703_registers[POWERCFG] |= (1<<SKMODE); //Disallow wrap - if you disallow wrap, you may want to tune to 87.5 first
  si4703_registers[POWERCFG] &= ~(1<<SKMODE); //Allow wrap
  if(seekDirection == SEEK_DOWN) si4703_registers[POWERCFG] &= ~(1<<SEEKUP); //Seek down is the default upon reset
  else si4703_registers[POWERCFG] |= 1<<SEEKUP; //Set the bit to seek up

  si4703_registers[POWERCFG] |= (1<<SEEK); //Start seek
  updateRegisters(); //Seeking will now start

  //Poll to see if STC is set
  while(1) {
    readRegisters();
    if((si4703_registers[STATUSRSSI] & (1<<STC)) != 0) break; //Tuning complete!
  }

  readRegisters();
  int valueSFBL = si4703_registers[STATUSRSSI] & (1<<SFBL); //Store the value of SFBL
  si4703_registers[POWERCFG] &= ~(1<<SEEK); //Clear the seek bit after seek has completed
  updateRegisters();

  //Wait for the si4703 to clear the STC as well
  while(1) {
    readRegisters();
    if( (si4703_registers[STATUSRSSI] & (1<<STC)) == 0) break; //Tuning complete!
  }

  if(valueSFBL) { //The bit was set indicating we hit a band limit or failed to find a station
    return(0);
  }
return getChannel();
}

//Reads the current channel from READCHAN
//Returns a number like 973 for 97.3MHz
int AK_Si4703::getChannel() {
//  readRegisters();
  int channel = si4703_registers[READCHAN] & 0x03FF; //Mask out everything but the lower 10 bits
  //Freq(MHz) = 0.100(in Europe) * Channel + 87.5MHz
  //X = 0.1 * Chan + 87.5
  //Serial.println(channel);
  channel = ((10 * channel) / 5) + 875;
  //Serial.println(channel);
  //channel += 875;
  //Serial.println(channel);
  //channel += 875; //98 + 875 = 973
  return(channel);
}

String AK_Si4703::getGroupType(uint16_t gt)
{
	String t;
	if (gt & 0x01)
		t = "B";
	else
		t = "A";
	return (String(gt >> 1) + t);
}

void AK_Si4703::resetRDS()
{
	for (int i = 0; i < 6; i++)
		rdsPTYcode[i] = 0;
	rdsState = RDSIDLE;
}
	
int AK_Si4703::getRegister(int reg) {
  readRegisters();
  return(si4703_registers[reg]);
}

void AK_Si4703::debugRDS(long timeout)
{ 
	long endTime = millis() + timeout;
  boolean completed[] = {false, false, false, false};
  int completedCount = 0;
  while(millis() < endTime) {
	readRegisters();
	if(si4703_registers[STATUSRSSI] & (1<<RDSR)){
		// ls 2 bits of B determine the 4 letter pairs
		// once we have a full set return
		// if you get nothing after 20 readings return with empty string
	  uint16_t b = si4703_registers[RDSB];
	  int index;
	    index = b & 0xF800;
	    
		if (index == 0x0001) {
		  //Basic Tuning Info
		  Serial.println(si4703_registers[RDSC], HEX);
		  Serial.println(si4703_registers[RDSD], HEX);
		  Serial.println("-------------------------");
		}
		else if (index == 0x2000) {
		  //Radio Text
		 index = b & 0x000F;
		 Serial.print("Radio Text: ");
		 Serial.println(index, HEX);
		 char Dh = (si4703_registers[RDSC] & 0xFF00) >> 8;
                 char Dl = (si4703_registers[RDSC] & 0x00FF);
		 Serial.print(Dh); Serial.print(Dl);
		  Dh = (si4703_registers[RDSD] & 0xFF00) >> 8;
                 Dl = (si4703_registers[RDSD] & 0x00FF);
		 Serial.print(Dh); Serial.println(Dl);
		 Serial.println(si4703_registers[RDSC], HEX);
		  Serial.println(si4703_registers[RDSD], HEX);
		  Serial.println("-------------------------");
		}
		else if (index == 0x3001) {
		  //Applications ID
		  Serial.println(si4703_registers[RDSC], HEX);
		  Serial.println(si4703_registers[RDSD], HEX);
		  Serial.println("-------------------------");
		}
		else if (index == 0x4001) {
		  //Time & Date
		  Serial.println(si4703_registers[RDSC], HEX);
		  Serial.println(si4703_registers[RDSD], HEX);
  	      Serial.println("-------------------------");
	 	}
		else if (index == 0xA001) {
		  //Program Type Name
		  Serial.println(si4703_registers[RDSC], HEX);
		  Serial.println(si4703_registers[RDSD], HEX);
		  Serial.println("-------------------------");
		}
		else if (index == 0xFFFF) {
		Serial.println(si4703_registers[RDSA], HEX);
		Serial.println(si4703_registers[RDSB], HEX);
		Serial.println(si4703_registers[RDSC], HEX);
		Serial.println(si4703_registers[RDSD], HEX);
		Serial.println("-------------------------");
		}
      delay(40); //Wait for the RDS bit to clear
	}
	else {
	  delay(30); //From AN230, using the polling method 40ms should be sufficient amount of time between checks
	}
  }
	if (millis() >= endTime) {
		//buffer[0] ='\0';
		return;
	}

  //buffer[8] = '\0';
}

void AK_Si4703::readRDS_Radiotext(char* buffer, unsigned long timeout)
{ 
	unsigned long startTime = millis();
	unsigned long endTime = startTime + timeout;
 	//boolean completed[] = {false, false, false, false};
	int completedCount = 0; //completedCount contains the status of the discovery...
	int indexHighest = 0;
  	while((millis() < endTime) && (completedCount < 8)) {
		readRegisters();
		if(si4703_registers[STATUSRSSI] & (1<<RDSR)) {
		  uint16_t b = si4703_registers[RDSB];
		  int index;
		  index = b & 0xF800;
		  if (index == 0x2000) {
			index = b & 0x0F;
			if (index > (indexHighest -1)) {
				indexHighest = index;
				completedCount++;
			}
			char Dh = (si4703_registers[RDSC] & 0xFF00) >> 8;
			char Dl = (si4703_registers[RDSC] & 0x00FF);
			buffer[(index * 4)] = Dh;
			buffer[(index * 4) + 1] = Dl;
			Dh = (si4703_registers[RDSD] & 0xFF00) >> 8;
	 		Dl = (si4703_registers[RDSD] & 0x00FF);
			buffer[(index * 4) + 2] = Dh;
			buffer[(index * 4) + 3] = Dl;
#if DEBUG
			//Serial.println(index);
			//Serial.print(Dh); Serial.print(","); Serial.println(Dl);
#endif
		  }
		  delay(40); //Wait for the RDS bit to clear
		} else {
		 delay(30); //From AN230, using the polling method 40ms should be sufficient amount of time between checks
		}
  	}
#if DEBUG
	unsigned long stopTime = millis();
  	Serial.print("indexHighest="); Serial.println(indexHighest);
	Serial.println("Elapsed time: " + String(stopTime - startTime));
#endif
  buffer[(indexHighest * 4) + 4] = '\0';
}
