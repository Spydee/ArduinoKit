/* 
David Willis
based on code from
	From Simon Monk. 2011-09-09
	Gary Bell 2013-12-05

To utilize the breakout board with 5V Micro, rewire RST pin to tie to VIO
through the 10K Resistor instead of ground.  Also disable the internal
pullup inside the twi.c file of the Wire library.

The Si4703 ACKs the first byte, and NACKs the 2nd byte of a read.

*/

#ifndef AK_Si4703_h
#define AK_Si4703_h

#include "Arduino.h"

	#define RDSINIT 0
	#define RDSIDLE 1
	#define RDSWAIT 2
	#define RDSGRPDEC 3
	#define RDSRADIOTIME 4
	#define RDSRADTXTSYNC 5
	#define RDSRADIOTEXT 6
	#define RDSDONE 8
	#define RDSGROUP00A	0x00	/*bsic tuning info */
	#define RDSGROUP00B	0x01	/*bsic tuning info */
	#define RDSGROUP01A	0x02	/*program item number */
	#define RDSGROUP01B	0x03	/*program item number */
	#define RDSGROUP02A	0x04	/*Radio text */
	#define RDSGROUP02B	0x05	/*Radio text */
	#define RDSGROUP03A	0x06	/*applications ID for ODA */
	#define RDSGROUP04A	0x08	/*Clock and Date */
	#define RDSGROUP08A	0x10	/*traffic */
	#define RDSGROUP09A	0x12	/*emergency Warning System */
	#define RDSGROUP10A	0x04	/*Program Type Name */
	
	#define RDSBTA 	(RDSGROUP00A)
	#define RDSBTB 	(RDSGROUP00B)
	#define RDSRTA	(RDSGROUP02A)
	#define RDSRTB	(RDSGROUP02B)
	#define RDSCLK	(RDSGROUP04A)
	
class AK_Si4703
{
  public:
    AK_Si4703(int resetPin, int sdioPin, int sclkPin);
    void powerOn();					// call in setup
	void intFunc();
	void setChannel(int channel);  	// 3 digit channel number
	int seekUp(); 					// returns the tuned channel or 0
	int seekDown(); 				
	void setVolume(int volume); 	// 0 to 15
	int  updateStatus();
	void updateRDS(long timeout);
	void readRDS(char* message, long timeout);	
									// message should be at least 9 chars
									// result will be null terminated
									// timeout in milliseconds
	int getRegister(int reg);
	void debugRDS(long timeout);
	void readRDS_Radiotext(char* message, unsigned long timeout);
	String getRDSProgtype();
	String strRDSText;
	
  private:
    int  _resetPin;
	int  _sdioPin;
	int  _sclkPin;

	uint8_t rdsState = RDSINIT;	
	uint16_t rdsPIcode;	// see http://www.rds.org.uk/2010/Glossary-Of-Terms.htm
	uint16_t rdsPTYcode[4];
	bool     rdsPTYgood = false;
	uint16_t rdsAFcode; // alternative frequency: used if RSSI level too low
	
	String rdsPTY[32] = {"","News","information","Sports", "Talk", "Rock", "Classic Rock", "Adult Hits", "Soft Rock", "Top 40", "Country",
						    "Oldies","Soft","Nostalgia","Jazz","Classical", "Rhythm and Blues","Soft Rhythm and Blues", "Religious Music","Religious Talk",
							"Personality", "Public", "College","","","","","","Weather"};

	String strRDSTemp;	// temp data for current read
	char rdsBuffer[100];
	uint16_t rdsIndex;
	uint16_t rdsRTindex;
	uint16_t rdsIndexMax; // where to put the null
	uint16_t rdsCLKindex;
	uint16_t rdsCLKindexMax; // where to put the null
	bool RTsync = false;	// RDS Radio Text synchronized read
	bool CLKsync = false;	// RDS Radio Clock synchronized
	
	void si4703_init();
	int readRegisters();
	byte updateRegisters();
	int seek(byte seekDirection);
	int getChannel();
	String getGroupType(uint16_t gt);
	uint16_t si4703_registers[16]; //There are 16 registers, each 16 bits large
	static const uint16_t  FAIL = 0;
	static const uint16_t  SUCCESS = 1;

	static const int  SI4703 = 0x10; //0b._001.0000 = I2C address of Si4703 - note that the Wire function assumes non-left-shifted I2C address, not 0b.0010.000W
	static const uint16_t  I2C_FAIL_MAX = 10; //This is the number of attempts we will try to contact the device before erroring out
	static const uint16_t  SEEK_DOWN = 0; //Direction used for seeking. Default is down
	static const uint16_t  SEEK_UP = 1;

	//Define the register names
	static const uint16_t  DEVICEID = 0x00;
	static const uint16_t  SICHIPID = 0x01;
	static const uint16_t  POWERCFG = 0x02;
	static const uint16_t  CHANNEL = 0x03;
	static const uint16_t  SYSCONFIG1 = 0x04;
	static const uint16_t  SYSCONFIG2 = 0x05;
	static const uint16_t  STATUSRSSI = 0x0A;
	static const uint16_t  READCHAN = 0x0B;
	static const uint16_t  RDSA = 0x0C;
	static const uint16_t  RDSB = 0x0D;
	static const uint16_t  RDSC = 0x0E;
	static const uint16_t  RDSD = 0x0F;

	//Register 0x02 - POWERCFG
	static const uint16_t  SMUTE = 15;
	static const uint16_t  DMUTE = 14;
	static const uint16_t  SKMODE = 10;
	static const uint16_t  SEEKUP = 9;
	static const uint16_t  SEEK = 8;

	//Register 0x03 - CHANNEL
	static const uint16_t  TUNE = 15;

	//Register 0x04 - SYSCONFIG1
	static const uint16_t  RDS = 12;
	static const uint16_t  DE = 11;

	//Register 0x05 - SYSCONFIG2
	static const uint16_t  SPACE1 = 5;
	static const uint16_t  SPACE0 = 4;

	//Register 0x0A - STATUSRSSI
	static const uint16_t  RDSR = 15;
	static const uint16_t  STC = 14;
	static const uint16_t  SFBL = 13;
	static const uint16_t  AFCRL = 12;
	static const uint16_t  RDSS = 11;
	static const uint16_t  STEREO = 8;
};

#endif
