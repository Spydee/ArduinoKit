/**
 * Copyright (c) 2019 by David Willis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */

#ifndef TEXTSCROLLER_h
#define TEXTSCROLLER_h

#include <Arduino.h>
#include <Ticker.h>
#include "AK_SH1106.h"

class AK_TextScroller {
	public:
	
//	AK_TextScroller();
	AK_TextScroller(SH1106 *dispPtr, uint16_t dispWidth);
//	~AK_TextScroller();
	
	void begin(uint16_t y, String scrolltext, uint16_t ticktime_ms);
	void drawString();
	void end();
	
	private:
	uint16_t widthDisp;
	uint16_t yloc;
	String text;
	uint16_t stringlen;
	OLEDDisplay	*mydisplayPtr;
	uint16_t tickms;
	Ticker myticker;
	uint16_t scrollPtr;
	void scrolltickISR();
	
};
#endif