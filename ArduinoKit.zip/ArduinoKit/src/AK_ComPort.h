/* 
David Willis
Creates a communication port using either SPI, I2C, or Serial port
Then uses read and write functions that know which one to used
*/

#ifndef AK_ComPort_h
#define AK_ComPort_h

#include "Arduino.h"

typedef struct _spiSettings
{
  uint8_t mosi_pin;		// data from Arduino to device
  uint8_t miso_pin;		// data from device to Arduino
  uint8_t sclk_pin;		// clock pin
  uint8_t cs_pin;		// chip select (slave select) pin
  uint32_t frequency;	// SPI clock frequency
  bool useHWcs;			// true if comPort handles SS, false if user code handles ss
} spiSettings;

typedef struct _i2cSettings
{
  uint8_t sda_pin;
  uint8_t scl_pin;
  uint8_t address;
  uint32_t frequency;
} i2cSettings;

typedef struct _serialSetting
{
  uint8_t txd_pin;
  uint8_t rxd_pin;
  uint32_t baudrate;
} serialSettings;

	
class AK_ComPort
{
  public:
    AK_ComPort();
	AK_ComPort(spiSettings settings);
	AK_ComPort(i2cSettings settings);
	AK_ComPort(serialSettings settings);
	
	void Write(byte *data, byte count);
//	void write(byte addr, byte data);
	void ReadBytes(byte * data, byte count);
//	void readBytes(byte address, byte * data, byte count);

  private:
	serialSettings serial;
	spiSettings spi;
	i2cSettings i2c;
	
};

#endif
