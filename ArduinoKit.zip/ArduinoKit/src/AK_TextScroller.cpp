/**
 * Copyright (c) 2019 by David Willis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */

 #include "AK_TextScroller.h"
/*
	AK_TextScroller::AK_TextScroller()
	{
		mydisplayPtr = 0;
	}
*/	
	AK_TextScroller::AK_TextScroller(SH1106 *dispPtr, uint16_t dispWidth)
	{
		mydisplayPtr = dispPtr;
		widthDisp = dispWidth;
	}

	void AK_TextScroller::begin(uint16_t y, String scrolltext, uint16_t ticktime_ms)
	{
		yloc = y;
		text = scrolltext;
		tickms = ticktime_ms;
		scrollPtr = widthDisp;	// start at the far right
		myticker.attach_ms(tickms, std::bind(&AK_TextScroller::scrolltickISR, this));
		stringlen = mydisplayPtr->getStringWidth(text);
	}
	
	void AK_TextScroller::scrolltickISR()
	{
	  scrollPtr -= 1;
	  if (scrollPtr < -stringlen)
		scrollPtr = widthDisp;
	}

	void AK_TextScroller::drawString()
	{
	  mydisplayPtr->setColor(BLACK);
	  mydisplayPtr->fillRect(0, yloc, widthDisp, 16);
	  mydisplayPtr->setColor(WHITE);
	  mydisplayPtr->drawString(scrollPtr, yloc, text);
	}
	
	void AK_TextScroller::end()
	{
		
		
	}
