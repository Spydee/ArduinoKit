#include <RAP.h>
//#include <Cirque_Trackpad.h>
#include <Curved_Overlay.h>
#include <Gestures.h>

#define DR_PIN D3
#define CS_PIN D8 


RAP_SPI myRAP0(DR_PIN, CS_PIN);
COC_Trackpad CirqueTP(&myRAP0);
Gestures gTest(true);

bool showdata = false;
byte data0[16];
byte data1[16];
absData_t touchData0;
absData_t touchData1;
buttons_t buttons0;
buttons_t buttons1;
