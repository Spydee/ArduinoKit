/**********************************************
 * These are for the radio
 **********************************************/
 #include "AK_Si4703.h"
 int RSTpin = D0; // Used for the radio
 const uint8_t SI4703_addr = 0x10; //fixed address of SI4703
 AK_Si4703 radio(RSTpin, SDApin, SCLpin);
 int channel;
 int volume;
 char rdsBuffer[128];
 uint16_t radioStatus = 0;
 uint16_t antLevel = 0;
 rdsData_t myRDSData;

void initializeRadio() {
  // put your setup code here, to run once:
  radio.powerOn();
  radio.setChannel(941);
}

int cnt = 0;
int seeks = 0;
String stRDS = "";

long seekStartTime;
long seekTime;
