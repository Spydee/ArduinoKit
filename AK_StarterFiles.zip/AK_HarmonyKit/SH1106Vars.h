/************************************************************************
 * SH1106 includes and variables
 ************************************************************************/
 #include "AK_SH1106.h"

/* 
 *  Just like your home, we need an address to send data to the display
 *  SH1106 is the protocol used by this display
 *  The SDA pin is the arduino pin the code uses for data
 *  The SCL pin is the clock pin used to tell the device when to read the data
 */
 const uint8_t SH1106_addr = 0x3c; // I2C address of display

/* 
 *  Display is 128 x 64
 *  Rows 0-15 (top) are for status of battery, antenna, etc
 *  Rows 16-31 are for song status (progress bar)
 *  Rows 32-47 are for scrolling text
 *  Rows 48-63 are for whatever
 *  
 *  For menu, use rows 16-63
 */

 const int16_t LINE1 = 0; // 0 to LINE2-1
 const int16_t LINE2 = 16; // 0 to LINE3-1
 const int16_t LINE3 = 32; // 0 to LINE4-1
 const int16_t LINE4 = 48; // 0 to LINE5-1

 // Initialize the OLED display using Wire library
 SH1106 display(SH1106_addr, SDApin, SCLpin, GEOMETRY_128_64);  // address, SDApin, SCLpin

void initializeDisplay()
{
  display.init();
  display.setContrast(255);  // maximum contrast
  display.setColor(WHITE);
  display.flipScreenVertically();
  display.clear();

  //Fonts: ArialMT_Plain_10, ArialMT_Plain_16, ArialMT_Plain_24
  //Alignment: TEXT_ALIGN_LEFT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER_BOTH
  display.setFont(ArialMT_Plain_10);
  display.setTextAlignment(TEXT_ALIGN_LEFT);
  display.drawString(128, LINE1, "waking up");

  display.display();

}
