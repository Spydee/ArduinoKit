
String myText = "";

String makeIndicator(uint16_t status, rdsData_t *data)
{
    String indicator = "";
    antLevel = status & 0x00FF;
    
    if (bitRead(status, 8) == 1)
      indicator += String(antLevel/8) + ";";
    else
      indicator += String(antLevel/8);
    return indicator; 
}

void updateScreen()
{
    myText = radio.getRDSProgtype() + " FM " + String( (radio.getChannel()/10.0) );
    display.drawString(0, LINE2, myText);
    display.setFont(Antenna);
    display.drawString(50, LINE1, makeIndicator(radioStatus, &myRDSData));
    display.setFont(ArialMT_Plain_10);
}
