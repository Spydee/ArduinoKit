/********************************************************************
 * Location and Axis class methods
 * Written by David Willis
 * Last updated July 24, 2018
 *******************************************************************/
#include "Location.h"

/********************************************************************
 * Axis class methods
 * Includes rotation, 
 *          translation, 
 *          and polar/rectangle coordinate conversions
 * The class methods are static so no need to instantiate
 ********************************************************************/

fLocation Axis::rotate(fLocation cur, double rad)
{
  cur.MP.ph += rad;
  cur.XY.x = cur.MP.mag*cos(cur.MP.ph);
  cur.XY.y = -cur.MP.mag*sin(cur.MP.ph);
  return cur;
}

fLocationR Axis::rotate(fLocationR cur, double rad)
{
  fLocationR temp;
      temp.x = (cur.x*cos(rad) + cur.y*sin(rad));
      temp.y = (-cur.x*sin(rad) + cur.y*cos(rad));
  return temp;
}

fLocationP Axis::rotate(fLocationP cur, double rad)
{
  cur.ph += rad;
  return cur;
}

fLocation Axis::translate(fLocation cur, double dx, double dy)
{
  cur.XY.x = cur.XY.x - dx;
  cur.XY.y = cur.XY.y - dy;
  cur.MP.mag = sqrt(cur.XY.x*cur.XY.x + cur.XY.y*cur.XY.y);
  cur.MP.ph = atan2(cur.XY.y, cur.XY.x);
  return cur;  
}

fLocationR Axis::translate(fLocationR cur, double dx, double dy)
{
  cur.x = cur.x - dx;
  cur.y = cur.y - dy;
  return cur;  
}

fLocationP Axis::translate(fLocationP cur, double dx, double dy)
{
  double x = cur.mag*cos(cur.ph) - dx;
  double y = cur.mag*sin(cur.ph) - dy;
  cur.mag = sqrt(x*x + y*y);
  cur.ph = atan2(y, x);
  return cur;
}

fLocationP Axis::toPolarf(fLocationR loc)
{
fLocationP newLoc = {sqrt(loc.x*loc.x + loc.y*loc.y), (atan2(loc.y,loc.x))};
return (newLoc);    
}

fLocationR Axis::toRectf(fLocationP loc)
{
fLocationR newLoc = {loc.mag*cos(loc.ph), loc.mag*sin(loc.ph)};
return (newLoc);    
}

/********************************************************************
 * Location class methods
 * Includes rotation, 
 *          translation, 
 *          and polar/rectangle coordinate conversions
 * The class methods are static so no need to instantiate
 ********************************************************************/

    Location::Location()
    {
      loc.x = 0;
      loc.y = 0;
      offset.x = 0;
      offset.y = 0;
    }

    Location::Location(float _x, float _y)
    {
      loc.x = _x;
      loc.y = _y;
	  magph = Axis::toPolarf(loc);
      offset.x = 0;
      offset.y = 0;
    }

    Location::Location(float _x, float _y, float _offX, float _offY)
    {
      loc.x = _x;
      loc.y = _y;
	  magph = Axis::toPolarf(loc);
	  offset.x = _offX;
      offset.y = _offY;
    }


  void Location::update(int _newX, int _newY)
  {
	  loc.x = _newX;
	  loc.y = _newY;
	  magph = Axis::toPolarf(loc);
  }

	fLocationR Location::getXY()
	{
		return loc;
	}
	
	fLocationP Location::getMagPhase()
	{
		return magph;
	}
	
/*************************** The End *****************************/