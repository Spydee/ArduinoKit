/********************************************************************
 * Cirque gestures processing
 * Written by David Willis
 * This file takes data from the Pinnacle trackpad and determines gestures
 *
 *******************************************************************/
 
#include <Gestures.h>
#include <Cirque_Structs.h>
#include <arduino.h>

/********************************************************************
 * Gestures class functions
 ********************************************************************/

/**************** Constructors **************************************/

	Gestures::Gestures()
	{
		init();
	}
	Gestures::Gestures(bool _reset)
	{
		init();
	}

	Gestures::Gestures(int16_t xmin, int16_t xmax, int16_t ymin, int16_t ymax)
	{
		init();		// init sets x and y min and max to +/-1000
		g_xmin = xmin;
		g_xmax = xmax;
		g_ymin = ymin;
		g_ymax = ymax;
		g_xrange = xmax - xmin;
		g_yrange = ymax - ymin;
	}

/***************************** Methods ******************************/

	GESTURES_ Gestures::getGesture()
	{
		return gesture;
	}

	void Gestures::init()
	{
	  g_xmin = -1000;
	  g_xmax = 1000;
	  g_ymin = -1000;
	  g_ymax = 1000;
	  g_yrange = 2000;
	  g_xrange = 2000;
      gesture = NONE;
	  state = IDLE;
//	  if (_reset)
		reset();
	}
	
	void Gestures::reset()
	{
	  avgdX = 0;
	  avgdY = 0;
	  avgdW = 0;
	  timeFirstTouch = 0;
	  timeLastTouch = 0;
	  timeTouchElapsed = 0;
	  for (int i = 0; i < PATHLENGTH; i++)
		path[i].XY = (fLocationR){0,0};
	  gesture = NONE;
	  
	} // end reset

	
/***********************************************
 * update the location data for the gestures
 * returns -2 if there are errors
 * returns -1 if no data
 * returns 0 if finger lifted
 * returns 1 if first touch
 * returns 2 if ongoing touch
 **********************************************/	
	int Gestures::update(absData_t touchData)
	{
	  int retval = 0;
	  gState_ next = IDLE;
	  gesture = NONE;
	  
	  switch(state)
	  {
		case IDLE:
		  if (touchData.touchDown)
		  {
			reset();
			firstTouch = true;
			retval = 1;
			timeFirstTouch = millis();
			next = DRAWING;
			path[0].XY = (fLocationR){touchData.xValue, touchData.yValue};
			path[0].MP = Axis::toPolarf(path[0].XY);
			locFirstTouch.XY = path[0].XY;
			locFirstTouch.MP = path[0].MP;
			locLastTouch.XY = path[0].XY;
			locLastTouch.MP = path[0].MP;
			
			pathIndex = 0;
		  }
		  else if (touchData.xValue == g_xmin)
			retval = -1;	// no data
		  else
			retval = -2;
		break;
		case DRAWING:
			if (touchData.touchDown)
			{
			  locLastTouch.XY = (fLocationR){touchData.xValue, touchData.yValue};
			  locLastTouch.MP = Axis::toPolarf(locLastTouch.XY);
			  deltaTimeTouch = millis() - timeLastTouch;
			  timeLastTouch = millis();
			  
			  timeTouchElapsed = timeLastTouch - timeFirstTouch;
			  filterData();
			  
			  retval = 2;
			  next = DRAWING;
			}
			else
			{
			  int totalDX = locLastTouch.XY.x - locFirstTouch.XY.x;
			  int totalDY = locLastTouch.XY.y - locFirstTouch.XY.y;

				if (timeTouchElapsed < 500)
				{
					if (      (avgdX < -3) && (totalDX < -(g_xrange/4)) )
						gesture = SWIPE_LEFT;
					else if ( (avgdX >  3) && (totalDX >  (g_xrange/4)) )
						gesture = SWIPE_RIGHT;
					else if ( (avgdY < -3) && (totalDY < -(g_yrange/4)) )
						gesture = SWIPE_DOWN;
					else if ( (avgdY > 3)  && (totalDY >  (g_yrange/4)) )
						gesture = SWIPE_UP;
					else if ( (timeTouchElapsed < 150) && (abs(totalDX) < 100) && (abs(totalDY) < 100) )
						gesture = TAP;
				}
				retval = 0;
				next = IDLE;
			}
			
		break;
	  }
	  state = next;
//		Serial.println("\n:***************" + String(touchData.xValue));
//		Serial.print(":**********X " + String(path[pathIndex].XY.x));
//		Serial.print(":*** dummy.x " + String(dummy.x));
//		Serial.print(":*** LT.y " + String(locLastTouch.XY.y));
	  return(retval);
	}

/*********************************************************
  function to determine if the finger is drawing a circle 
  or going left to right or up and down
  
  criteria
	circle if 
		1. finger on outside quarter of circle 
		2. phase change but not too fast or too slow , constant magnitude
		2. X and Y have small delta since last touch
		3. Finger must be down more than 500 ms
		4. Keep track of dPh, dW, dMag and dPh
		
	swipe up/down if
		1. Y changing, X near center of pad
		2. Finger down more than 100ms and less than 500ms
		3. Uses dX and dY and the time finger was touching
		4. Finger just lifted
	
	swipe left/right if
		1. X changing, Y near center of pad
		2. Finger down more than 100ms and less than 500ms
		3. Uses dX and dY and the time finger was touching
		4. Finger just lifted
	
	tap
		1. Finger down less than 100ms
		2. dX, dY less than range / 10
		3. finger must be up
	
	track
		1. Finger down more than 500ms
		2. dXdt and dYdt less than ?? (slow move)
		3. keeps track of dX and dY and dPh and dMag over 200ms
		
		
  
  must be called after filterData to get good date
*********************************************************/
	int16_t Gestures::checkForGesture()
	{
	  if ( ( (timeLastTouch - rotateTime) > 100) && (timeTouchElapsed > 300) )
	  {
		rotateTime = timeLastTouch;
		// since we are rotating, assume xrange and y range the same
		if ( (avgdW > 2) && (locLastTouch.MP.mag > g_xrange/4) )
			gesture = ROTATE_LEFT;
		else if ( (avgdW < -2) && (locLastTouch.MP.mag > g_xrange/4) )
			gesture = ROTATE_RIGHT;
	  }
	}

void Gestures::filterData()
{
  int i;
  for (i = PATHLENGTH-1; i > 0; i--)
	  path[i] = path[i-1];
  path[0] = locLastTouch;
  double temp;

  avgdX = (locLastTouch.XY.x - locFirstTouch.XY.x)/(double)timeTouchElapsed;
  avgdY = (locLastTouch.XY.y - locFirstTouch.XY.y)/(double)timeTouchElapsed;
  
  temp = 1000*(path[0].MP.ph - path[1].MP.ph)/(double)deltaTimeTouch;
  avgdW = (temp + avgdW)/2.0;
	
//  avgdX = ((avgdX * (pathIndex-1)) + dX/dt)/pathIndex;
//  avgdY = ((avgdY * (pathIndex-1)) + dY/dt)/pathIndex;
}

	
	fLocationR Gestures::getCurrentLocation()
	{
		//return (dummy);
		return(locLastTouch.XY);
	}
	
	double Gestures::getdXdt()
	{
		return (avgdX);
	}
		
	double Gestures::getdYdt()
	{
		return(avgdY);
	}

	double Gestures::getdPh()
	{
	}
	
	double Gestures::getW()
	{
		return(avgdW);
	}
	long Gestures::getTouchTime()
	{
		return(timeTouchElapsed);
	}
	
	
	/****************
	bool Gestures::firstTouch(bool newTouch)
	{
	  bool first = false;
      if (!prevTouch) // we weren't touching before
	  {
		if (newTouch)
		{
		  first = true;
	#ifdef DEBUG_GESTURES
		  Serial.println("First Touch");
		  Serial.println();
		}
	  }
	  prevTouch = newTouch;
      return (first);
	}
    ***********************/