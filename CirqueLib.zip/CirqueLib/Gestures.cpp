/********************************************************************
 * Cirque gestures processing
 * Written by David Willis
 * This file takes data from the Pinnacle trackpad and determines gestures
 *
 *******************************************************************/
 
#include <Gestures.h>
#include <Cirque_Structs.h>
#include <arduino.h>

/********************************************************************
 * Gestures class functions
 ********************************************************************/

/**************** Constructors **************************************/

	Gestures::Gestures()
	{
		init();
	}
	Gestures::Gestures(bool _reset)
	{
		init();
	}

/***************************** Methods ******************************/

	GESTURES_ Gestures::getGesture()
	{
		return gesture;
	}

/*	
	bool Gestures::processData(absData_t touch)
	{
	 // based on Location information, determine the gesture
	 // This method is called by the ISR
		bool gestAvail = false;
		gesture = NONE;
		
		locHistory[0].update(touch.xValue, touch.yValue);
		
		fLocationP _polar = Axis::toPolarf(locHistory[0].loc);
		
		if ( (_polar.ph > 0) & (_polar.ph < 45) )
		{
			gesture = ROTATE_RIGHT;
			gestAvail = true;
		}
		if ( (_polar.ph > -45) & (_polar.ph < 0) )
		{
			gesture = ROTATE_LEFT;
			gestAvail = true;
		}
		if ( (_polar.ph > 45) & (_polar.ph < 135) )
		{
			gesture = SWIPE_UP;
			gestAvail = true;
		}
		return(gestAvail);
	}
*/

	void Gestures::init()
	{
      gesture = NONE;
	  state = IDLE;
//	  if (_reset)
		reset();
	}
	
	void Gestures::reset()
	{
	  avgdX = 0;
	  avgdY = 0;
	  avgdW = 0;
	  timeFirstTouch = 0;
	  timeTouchElapsed = 0;
	  for (int i = 0; i < PATHLENGTH; i++)
		path[i].XY = (fLocationR){0,0};
	  gesture = NONE;
	  
	} // end reset

	
/***********************************************
 * update the location data for the gestures
 * returns -2 if there are errors
 * returns -1 if no data
 * returns 0 if finger lifted
 * returns 1 if first touch
 * returns 2 if ongoing touch
 **********************************************/	
	int Gestures::update(absData_t touchData)
	{
	  int retval = 0;
	  gState_ next = IDLE;
	  
	  switch(state)
	  {
		case IDLE:
		  if (touchData.touchDown)
		  {
			reset();
			firstTouch = true;
			retval = 1;
			timeFirstTouch = millis();
			next = DRAWING;
			path[0].XY = (fLocationR){touchData.xValue, touchData.yValue};
			locFirstTouch.XY = path[0].XY;
			locLastTouch.XY = path[0].XY;
			pathIndex = 0;
		  }
		  else if (touchData.xValue == 0)
			retval = -1;	// no data
		  else
			retval = -2;
		break;
		case DRAWING:
			if (touchData.touchDown)
			{
			  locLastTouch.XY = (fLocationR){touchData.xValue, touchData.yValue};
			  locLastTouch.MP = Axis::toPolarf(locLastTouch.XY);
			  
			  timeLastTouch = millis();
			  timeTouchElapsed = timeLastTouch - timeFirstTouch;
			  filterData();
			  
			  retval = 2;
			  next = DRAWING;
			}
			else
			{
			  int totalDX = locLastTouch.XY.x - locFirstTouch.XY.x;
			  int totalDY = locLastTouch.XY.y - locFirstTouch.XY.y;

			  gesture = NONE;
				if (timeTouchElapsed < 500)
				{
					if ( (avgdX < -3) && (totalDX < -500) )
						gesture = SWIPE_LEFT;
					else if ( (avgdX > 3) && (totalDX > 500) )
						gesture = SWIPE_RIGHT;
					else if ( (avgdY < -3) && (totalDY < -500) )
						gesture = SWIPE_DOWN;
					else if ( (avgdY > 3)  && (totalDY > 500) )
						gesture = SWIPE_UP;
					else if ( (timeTouchElapsed < 150) && (abs(totalDX) < 100) && (abs(totalDY) < 100) )
						gesture = TAP;
				}
				retval = 0;
				next = IDLE;
			}
			
		break;
	  }
	  state = next;
//		Serial.println("\n:***************" + String(touchData.xValue));
//		Serial.print(":**********X " + String(path[pathIndex].XY.x));
//		Serial.print(":*** dummy.x " + String(dummy.x));
//		Serial.print(":*** LT.y " + String(locLastTouch.XY.y));
	  return(retval);
	}

void Gestures::filterData()
{
  int i;
  for (i = PATHLENGTH-1; i > 0; i--)
	  path[i] = path[i-1];
  path[0] = locLastTouch;

  avgdX = (locLastTouch.XY.x - locFirstTouch.XY.x)/(double)timeTouchElapsed;
  avgdY = (locLastTouch.XY.y - locFirstTouch.XY.y)/(double)timeTouchElapsed;
	
//  avgdX = ((avgdX * (pathIndex-1)) + dX/dt)/pathIndex;
//  avgdY = ((avgdY * (pathIndex-1)) + dY/dt)/pathIndex;
}

	
	fLocationR Gestures::getCurrentLocation()
	{
		//return (dummy);
		return(locLastTouch.XY);
	}
	
	double Gestures::getdXdt()
	{
		return (avgdX);
	}
		
	double Gestures::getdYdt()
	{
		return(avgdY);
	}
	long Gestures::getTouchTime()
	{
		return(timeTouchElapsed);
	}
	
	
	/****************
	bool Gestures::firstTouch(bool newTouch)
	{
	  bool first = false;
      if (!prevTouch) // we weren't touching before
	  {
		if (newTouch)
		{
		  first = true;
	#ifdef DEBUG_GESTURES
		  Serial.println("First Touch");
		  Serial.println();
		}
	  }
	  prevTouch = newTouch;
      return (first);
	}
    ***********************/