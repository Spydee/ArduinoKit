/*********************************************************
 * This file is part of the Cirque circle 
 * sensor library for Arduino.
 * Written by David Willis, it is modified from
 * the code initially written by Patrick Sherwood.
 * This code is Copyright David Willis.
 * All rights are reserved.
 * Code may be used for commercial or private use.
 * Code may not be used for military or illegal purposes.
 *
 ********************************************************/
#ifndef CIRQUE_STRUCTS_H
#define CIRQUE_STRUCTS_H

#include <arduino.h>
// Convenient way to store and access measurements
typedef struct _absData
{
  int16_t xValue;
  int16_t yValue;
  int16_t zValue;
  bool touchDown;
  bool hovering;  
} absData_t;

typedef struct _relData
{
  int8_t dX;
  int8_t dY;
  bool touchDown;
} relData_t;

typedef struct _buttons
{
  bool left;
  bool right;
  bool middle;
} buttons_t;

// same as absData but with time stamp
typedef struct _absDataTS
{
  int16_t xValue;
  int16_t yValue;
  int16_t zValue;
  bool touchDown;
  long timeStamp;
} absDataTS_t;  
	
 #endif