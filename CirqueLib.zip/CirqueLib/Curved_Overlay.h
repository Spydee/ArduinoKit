/***************************************************************
 * Cirque_Trackpad TMxx Circular Track Pad library for curved overlays
 * Written by David Willis
 *
 * Supports Cirque TM040040 and TM035035 track pads
 
 * code is built to work with a Teensy 3.1/3.2 but it can easily be adapted to
 * work with Arduino-based systems.

 * Supports I2C or SPI communication. 
 * 	  To determine how your touch pad is configured check if R1 (or the resistor 
 *    that connects pins 24 & 25 * of the 1CA027 IC) is installed
 *			for I2C-mode, make sure that R1 is NOT populated
 *			for SPI a 470 ohm resistor should be installed
 *
 * FPC connector pinout
 *   1 VDD 2.7V to 3.3V
 *   2 GND
 *   3 SDA    - I2C
 *   4 SCL    - I2C
 *   5 BUTTON1
 *   6 BUTTON3
 *   7 BUTTON2
 *   8 MOSI - SPI
 *   9 DR   - Data Ready when high
 *  10 SS   - SPI
 *  11 MISO - SPI
 *  12 SCK  - SPI CLOCK
 
 
 *  Pinnacle TM040040 with Arduino
 *  Hardware Interface for Teensy
 *  GND
 *  +3.3V
 *  SDA = Pin 18  (there MUST be a pull-up to 3.3V on this signal; 4.7k recommended)
 *  SCL = Pin 19  (there MUST be a pull-up to 3.3V on this signal; 4.7k recommended)
 *  DR = Pin 9
 *
 * Hardware Interface for ESP8266 with display
 *  SDA = Pin D1  (I2C display has pullup already)
 *  SCL = Pin D2  (I2C display has pullup already)
 *  DR = ?
 *
 * This file is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU General Public License version 2
 * or the GNU Lesser General Public License version 2.1, both as
 * published by the Free Software Foundation.
 *************************************************************************************/
#include <Cirque_Structs.h>

#ifndef COC_TRACKPAD
#define COC_TRACKPAD

#include <SPI.h>	// for SPI mode
#include <Wire.h>	// for I2C mode
#include "RAP.h"

// Register config values for this demo
#define SYSCONFIG_1   0x00
#define Z_IDLE_COUNT  0x01

/** Feed Config1 register settings *********/
/* FEEDCONFIG_1 is the preferred setting **/
#define FDC1_REG		0x04
#define FEEDCONFIG_1	0x03
#define FDC_ENABLE		0x01
#define FDC_ABS			0x01
#define FDC_REL			0x00
#define FDC_FLTROFF		0x04
#define FDC_XINVERT		0x40
#define FDC_YINVERT		0x80
//#define FDC_XDISABLE	0x08
//#define FDC_YDISABLE	0x10

/** Feed Config2 register settings *********/
/* FEEDCONFIG_2 is the preferred setting **/
#define FDC2_REG		0x05
#define FEEDCONFIG_2  	0x1F
#define FDC2_XYSWAP		0x80	// swap X and Y axis (rotate 90 deg)
#define FDC2_EXTND_OFF	0x10	// disable Glidepoint extend
#define FDC2_SCRL_OFFF	0x08	// disable scroll
#define FDC2_STAP_OFF	0x04	// disable secondary taps
#define FDC2_ALLTAP_OFF	0x02	// disable all taps
#define FDC2_INTLMOUSE	0x01	// enable the intellimouse buttons 


/*****************************
35mm XMAX = 1948, XMIN = 293, YMAX = 1505, YMIN = 192
40mm XMAX = 1764, XMIN = 129, YMAX = 1395, YMIN = 42
Per GP-DS-170409 TM035035 documentation
	theoretical:	0 < X < 2048, 0 < Y < 1536
	actual: 		128 < X < 1920, 64 < Y < 1472
******************************/

// Coordinate scaling values
#define PINNACLE_XMAX     2047    // max value Pinnacle can report for X
#define PINNACLE_YMAX     1535    // max value Pinnacle can report for Y

#ifdef PINNACLE_40MM
	#define PINNACLE_X_LOWER  130     // min "reachable" X value: was 129
	#define PINNACLE_X_UPPER  1800    // max "reachable" X value: was 1764
	#define PINNACLE_Y_LOWER  70     // min "reachable" Y value: was 42
	#define PINNACLE_Y_UPPER  1430    // max "reachable" Y value: was 1395
#else
	#define PINNACLE_X_LOWER  127     // min "reachable" X value
	#define PINNACLE_X_UPPER  1919    // max "reachable" X value
	#define PINNACLE_Y_LOWER  63      // min "reachable" Y value
	#define PINNACLE_Y_UPPER  1471    // max "reachable" Y value
#endif

#define PINNACLE_X_RANGE  (PINNACLE_X_UPPER-PINNACLE_X_LOWER)
#define PINNACLE_Y_RANGE  (PINNACLE_Y_UPPER-PINNACLE_Y_LOWER)
#define PINNACLE_X_MID (PINNACLE_X_UPPER+PINNACLE_X_LOWER)/2
#define PINNACLE_Y_MID (PINNACLE_Y_UPPER+PINNACLE_Y_LOWER)/2

#define ZONESCALE 256   // divisor for reducing x,y values to an array index for the LUT
#define ROWS_Y ((PINNACLE_YMAX + 1) / ZONESCALE) 
#define COLS_X ((PINNACLE_XMAX + 1) / ZONESCALE)


// ADC-attenuation settings (held in BIT_7 and BIT_6)
// 1X = most sensitive, 4X = least sensitive
#define ADC_ATTENUATE_1X   0x00
#define ADC_ATTENUATE_2X   0x40
#define ADC_ATTENUATE_3X   0x80
#define ADC_ATTENUATE_4X   0xC0

/*********
// Convenient way to store and access measurements
typedef struct _absData
{
  int16_t xValue;
  int16_t yValue;
  int16_t zValue;
  bool touchDown;
  bool hovering;  
} absData_t;

// Convenient way to store and access measurements
typedef struct _relData
{
  int8_t dX;
  int8_t dY;
  bool touchDown;
} relData_t;

typedef struct _buttons
{
  bool left;
  bool right;
  bool middle;
} buttons_t;
*************/

/***************************************
 see https://static1.squarespace.com/static/53233e4be4b044fa7626c453/t/599de7856f4ca3c38aa74632/1503520647200/GT-AN-090620_2-4_InterfacingtoPinnacle_I2C-SPI_DOCVer1-6.pdf
for the complete description
******************************************/
typedef struct Pinnacle_map
{
  byte FirmwareID;		// 0x00
  byte FirmwareVersion;	// 0x01
  byte Status;			// 0x02
  byte SysConfig1;		// 0x03
  byte FeedConfig1;		// 0x04
  byte FeedConfig2;		// 0x05
  byte Reserved1;		// 0x06
  byte CalConfig1;		// 0x07
  byte PS2AuxControl;	// 0x08
  byte SampleRate;		// 0x09
  byte ZIdle;			// 0x0A
  byte ZScaler;			// 0x0B
  byte SleepInterval;	// 0x0C
  byte SleepTimer;		// 0x0D
  byte Reserved2;		// 0x0E
  byte Reserved3;		// 0x0F
  byte Reserved4;		// 0x10
  byte Reserved5;		// 0x11
  byte Buttons;			// 0x12
} Pinnacle_map_t;

/*****************************************************
 * These values require tuning for optimal touch-response
 * Each element represents the Z-value below which is
 * considered "hovering" in that XY region of the sensor. 
 * The values present are not guaranteed to work for all 
 * HW configurations.
 *****************************************************/
const uint8_t ZVALUE_MAP[ROWS_Y][COLS_X] =
{
  {0, 0,  0,  0,  0,  0, 0, 0},
  {0, 2,  3,  5,  5,  3, 2, 0},
  {0, 3,  5, 15, 15,  5, 2, 0},
  {0, 3,  5, 15, 15,  5, 3, 0},
  {0, 2,  3,  5,  5,  3, 2, 0},
  {0, 0,  0,  0,  0,  0, 0, 0},  
};

class COC_Trackpad {


public:

//Constructors
  COC_Trackpad(int _mode);
  COC_Trackpad(RAP_ *pR);

// Pinnacle read/write funtions
  void Pinnacle_Init();
  void Pinnacle_ClearFlags();
  void Pinnacle_GetAbsolute(absData_t * result);
  void Pinnacle_GetButtons(buttons_t * btns);
  bool zIdlePacket(absData_t * data);

  // RAP low level functions
  void ReadBytes(byte address, byte * data, byte count);
  void Write(byte addr, byte data);

// Data manipulation functions  
  void SetDefaultScale();
  void SetScale(bool _scale_en, int16_t _xmin, int16_t _xmax, int16_t _ymin, int16_t _ymax);
  void ClipCoordinates(absData_t * coordinates);
  void ScaleData(absData_t * coordinates);

  void setAdcAttenuation(uint8_t adcGain);
  void tuneEdgeSensitivity();
  void Pinnacle_CheckValidTouch(absData_t * data); // Checks for "hover" caused by curved overlay

  // Enables/Disables the feed
  void Pinnacle_EnableFeed(bool feedEnable);

private:
absData_t touchData;		// make these private later
RAP_* pRAP;
int mode = SPI_0;
bool scale_en = false;
int16_t tp_xmin;
int16_t tp_xmax;
int16_t tp_xmid;
int32_t xResolution;
int16_t tp_ymin;
int16_t tp_ymax;
int16_t tp_ymid;
int32_t yResolution;
	  
	
}; // end Curved overlay class

#endif
