#include <RAP.h>
//#include <Cirque_Trackpad.h>
#include <Curved_Overlay.h>
#include <Gestures.h>

#define DR_PIN D3
#define CS_PIN D8 

//RAP_I2C(DR_PIN, SCL_PIN, SDA_PIN);	// use this for I2C connections
RAP_SPI myRAP0(DR_PIN, CS_PIN);			// use this for SPI connections
COC_Trackpad CirqueTP(&myRAP0);
Gestures gTest(true);

bool showdata = false;
byte data0[16];
byte data1[16];
absData_t touchData0;
absData_t touchData1;
buttons_t buttons0;
buttons_t buttons1;


// Functions used
void getTPstatus()
{
	byte data[3];

	Serial.println("Read Firmware ID, version and device status");
	CirqueTP.ReadBytes(0x00, data, 3);
	Serial.println("Register\t|Value\t|");
	Serial.print("Firmware ID\t|");
	Serial_PrintHEX8((uint8_t)data[0]);
	Serial.println("\t|");
	Serial.print("Firmware Ver.\t|");
	Serial_PrintHEX8((uint8_t)data[1]);
	Serial.println("\t|");
	Serial.print("Status     \t|");
	Serial_PrintHEX8((uint8_t)data[2]);
	Serial.println("\t|");

	clear the status and read it back again
	CirqueTP.Write(0x02, 0x00);
	CirqueTP.ReadBytes(0x00, data, 3);
	Serial.print("Status cleared\t|");
	Serial_PrintHEX8((uint8_t)data[2]);
	Serial.println("\t|");
}

void Serial_PrintHEX8(uint8_t d)
{
	Serial.print("0x");
	if (d < 16)
		Serial.print("0");
	Serial.print(d, HEX);
}