/**************************************************************************************
 * Cirque_Trackpad TMxx Circular Track Pad library and class structure
 * Written by David Willis
 *
 * Supports Cirque TM040040 and TM035035 track pads
 
 * code is built to work with a Teensy 3.1/3.2 but it can easily be adapted to
 * work with Arduino-based systems.

 * Supports I2C or SPI communication. 
 * 	  To determine how your touch pad is configured check if R1 (or the resistor 
 *    that connects pins 24 & 25 * of the 1CA027 IC) is installed
 *			for I2C-communication, make sure that R1 is NOT populated
 *			for SPI a 470 ohm resistor should be installed
 
 *  Pinnacle TM040040 with Arduino
 *  Hardware Interface
 *  GND
 *  +3.3V
 *  SDA = Pin 18  (there MUST be a pull-up to 3.3V on this signal; 4.7k recommended)
 *  SCL = Pin 19  (there MUST be a pull-up to 3.3V on this signal; 4.7k recommended)
 *  DR = Pin 9
 * This file is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU General Public License version 2
 * or the GNU Lesser General Public License version 2.1, both as
 * published by the Free Software Foundation.
 *************************************************************************************/

#ifndef CIRQ_TRACKPAD
#define CIRQ_TRACKPAD

#include <SPI.h>	// for SPI comport
#include <Wire.h>	// for I2C comport
#include "RAP.h"

// Register config values for this demo
#define SYSCONFIG_1   0x00
#define Z_IDLE_COUNT  0x00

/** Feed Config1 register settings *********/
/* FEEDCONFIG_1 is the preferred setting **/
#define FDC1_REG		0x04
#define FEEDCONFIG_1	0x03
#define FDC_ENABLE		0x01
#define FDC_ABS			0x01
#define FDC_REL			0x00
#define FDC_FLTROFF		0x04

/** Feed Config2 register settings *********/
/* FEEDCONFIG_2 is the preferred setting **/
#define FDC2_REG		0x05
#define FEEDCONFIG_2  	0x1F
#define FDC2_XYSWAP		0x80
#define FDC2_EXTND_OFF	0x10
#define FDC2_SCRL_OFFF	0x08
#define FDC2_STAP_OFF	0x04
#define FDC2_ALLTAP_OFF	0x02
#define FDC2_INTLMOUSE	0x01

/*****************************************************
35mm XMAX = 1948, XMIN = 293, YMAX = 1505, YMIN = 192
40mm XMAX = 1764, XMIN = 129, YMAX = 1395, YMIN = 42
Per GP-DS-170409 TM035035 documentation
	theoretical:	0 < X < 2048, 0 < Y < 1536
	actual: 		128 < X < 1920, 64 < Y < 1472
******************************************************/

// Coordinate scaling values
#define PINNACLE_XMAX     2047    // max value Pinnacle can report for X
#define PINNACLE_YMAX     1535    // max value Pinnacle can report for Y
#define PINNACLE_X_LOWER  127     // min "reachable" X value
#define PINNACLE_X_UPPER  1919    // max "reachable" X value
#define PINNACLE_Y_LOWER  63      // min "reachable" Y value
#define PINNACLE_Y_UPPER  1535    // max "reachable" Y value
#define PINNACLE_X_RANGE  (PINNACLE_X_UPPER-PINNACLE_X_LOWER)
#define PINNACLE_Y_RANGE  (PINNACLE_Y_UPPER-PINNACLE_Y_LOWER)

#define ZONESCALE 256   // divisor for reducing x,y values to an array index for the LUT
#define ROWS_Y ((PINNACLE_YMAX + 1) / ZONESCALE) 
#define COLS_X ((PINNACLE_XMAX + 1) / ZONESCALE)


// ADC-attenuation settings (held in BIT_7 and BIT_6)
// 1X = most sensitive, 4X = least sensitive
#define ADC_ATTENUATE_1X   0x00
#define ADC_ATTENUATE_2X   0x40
#define ADC_ATTENUATE_3X   0x80
#define ADC_ATTENUATE_4X   0xC0

#include <Cirque_Structs.h>

/***************************************
 see https://static1.squarespace.com/static/53233e4be4b044fa7626c453/t/599de7856f4ca3c38aa74632/1503520647200/GT-AN-090620_2-4_InterfacingtoPinnacle_I2C-SPI_DOCVer1-6.pdf
for the complete description
******************************************/
typedef struct Pinnacle_map
{
  byte FirmwareID;		// 0x00
  byte FirmwareVersion;	// 0x01
  byte Status;			// 0x02
  byte SysConfig1;		// 0x03
  byte FeedConfig1;		// 0x04
  byte FeedConfig2;		// 0x05
  byte Reserved1;		// 0x06
  byte CalConfig1;		// 0x07
  byte PS2AuxControl;	// 0x08
  byte SampleRate;		// 0x09
  byte ZIdle;			// 0x0A
  byte ZScaler;			// 0x0B
  byte SleepInterval;	// 0x0C
  byte SleepTimer;		// 0x0D
  byte Reserved2;		// 0x0E
  byte Reserved3;		// 0x0F
  byte Reserved4;		// 0x10
  byte Reserved5;		// 0x11
  byte Buttons;			// 0x12
} Pinnacle_map_t;


class Cirque_Trackpad {


public:
absData_t touchData;		// make these private later
RAP_* pRAP;
int comport = SPI_0;
bool scale_en = false;
int16_t xmin = 0;
int16_t xmax = PINNACLE_XMAX;
int16_t ymin = 0;
int16_t ymax = PINNACLE_YMAX;

//Constructors
  Cirque_Trackpad(int _comport);
  Cirque_Trackpad(RAP_ *pR);

// Pinnacle read/write funtions
  void Pinnacle_Init();
  void Pinnacle_ClearFlags();
  void Pinnacle_GetAbsolute(absData_t * result);
  void Pinnacle_GetButtons(buttons_t * btns);
  void Pinnacle_GetAbsolute(absData_t * result, buttons_t * btns);
  void Pinnacle_GetRelative(relData_t * result);
  bool Pinnacle_zIdlePacket(absData_t * data);

// RAP low level functions
  void ReadBytes(byte address, byte * data, byte count);
  void Write(byte addr, byte data);

// Data manipulation functions  
  void SetScale(bool _scale_en, int16_t _xmin, int16_t _xmax, int16_t _ymin, int16_t _ymax);
  void ClipCoordinates(absData_t * coordinates);
  void ScaleData(absData_t * coordinates);
  
  
private:
// Enables/Disables the feed
  void Pinnacle_EnableFeed(bool feedEnable);
	  
	  
}; // end class

#endif
