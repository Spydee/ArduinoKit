/*******************************************
 * This file is part of the Cirque circle 
 * sensor library for Arduino.
 * Written by David Willis, it is modified from
 * the code initially written by Patrick Sherwood.
 * This code is Copyright David Willis.
 * All rights are reserved.
 * Code may be used for commercial or private use.
 * Code may not be used for military or illegal purposes.
 *
 *******************************************/
#ifndef CIRQUE_BOARDS_H
#define CIRQUE_BOARDS_H

/*********************************************
 * Define the default pins and setup
 *   These can be modified using the various 
 *   methods in the RAP class
 *********************************************/
#ifdef ESP8266
	// Hardware pin-number - general
	#define DR0_PIN   D3

// Hardware pin-number labels for I2C
	#define SDA_PIN   D1
	#define SCL_PIN   D2

// Hardware pin-number labels for SPI
	#define SCK_PIN   D5
	#define DIN_PIN   D6
	#define DOUT_PIN  D7
	#define CS0_PIN   D8
	#define SPI_CLKF  5000000
#endif

#ifdef TEENSY
	// Hardware pin-number - general
	#define DR0_PIN    9
	#define DR1_PIN    7
	#define LED_0     21
	#define LED_1     20

// Hardware pin-number labels for I2C
	#define SDA_PIN   18
	#define SCL_PIN   19

// Hardware pin-number labels
	#define SCK_PIN   13
	#define DIN_PIN   12
	#define DOUT_PIN  11
	#define CS0_PIN   10
	#define CS1_PIN    8
#endif

// Protocol definitions for RAP_ class
#define SPI_0	0
#define SPI_1	1
#define I2C_0	2
#define I2C_1	3

// Masks for Cirque Register Access Protocol (RAP)
#define WRITE_MASK  0x80
#define READ_MASK   0xA0

// Cirque's 7-bit I2C Slave Address
#define SLAVE_ADDR  0x2A


#endif
