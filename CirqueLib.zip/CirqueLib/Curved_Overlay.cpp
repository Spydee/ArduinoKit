/***************************************************************
 * Cirque Curved overlay TMxx Circular Track Pad library
 * Written by David Willis
 *
 * Supports Cirque TM040040 and TM035035 track pads
 
 * code is built to work with a Teensy 3.1/3.2 but it can easily be adapted to
 * work with Arduino-based systems.

 * Supports I2C or SPI communication. 
 * 	  To determine how your touch pad is configured check if R1 (or the resistor 
 *    that connects pins 24 & 25 * of the 1CA027 IC) is installed
 *			for I2C-mode, make sure that R1 is NOT populated
 *			for SPI a 470 ohm resistor should be installed
 
 *  Pinnacle TM040040 with Arduino
 *  Hardware Interface for Teensy
 *  GND
 *  +3.3V
 *  SDA = Pin 18  (there MUST be a pull-up to 3.3V on this signal; 4.7k recommended)
 *  SCL = Pin 19  (there MUST be a pull-up to 3.3V on this signal; 4.7k recommended)
 *  DR = Pin 9
 *
 * Hardware Interface for ESP8266 with display
 *  SDA = Pin D1  (I2C display has pullup already)
 *  SCL = Pin D2  (I2C display has pullup already)
 *  DR = Pin 9
 *
 * The pad is configured for Absolute mode tracking.  Touch data is sent in text format over USB CDC to
 * the host PC.  You can open a terminal window on the PC to the USB CDC port and see X, Y, and Z data
 * scroll up the window when you touch the sensor. Tools->Serial Monitor can be used to view touch data.
 ***************************************************************/
#include "Curved_Overlay.h"

/*****************************************************
 * Trackpad class functions
 *****************************************************/

/**************** Constructors ***********************/
// mode is SPI_0, SPI_1, I2C_0 or I2C_1
	COC_Trackpad::COC_Trackpad(int _mode)
	{
	  switch (_mode) {
	  case SPI_0:
	  case SPI_1:	pRAP = new RAP_SPI(_mode);
	  break;
	  case I2C_0:
	  case I2C_1:	pRAP = new RAP_I2C(_mode);
	  break;
	  default:		pRAP = new RAP_SPI(SPI_0);
	  break;
	  } // switch
	  Pinnacle_Init();
	  SetDefaultScale();
	} // constructor

	COC_Trackpad::COC_Trackpad(RAP_ *pR)
	{
		pRAP = pR;
		Pinnacle_Init();
//		SetDefaultScale();
	}

 
/******************************************************
 * Curved Trackpad functions
 ******************************************************/

void COC_Trackpad::SetDefaultScale()
{
	tp_xmin = PINNACLE_X_LOWER;
	tp_xmax = PINNACLE_XMAX;
	tp_xmid = (tp_xmin + tp_xmax)/2;
	xResolution = (tp_xmax - tp_xmin);
	
	tp_ymin = PINNACLE_Y_LOWER;
	tp_ymax = PINNACLE_YMAX;
	tp_ymid = (tp_ymin + tp_ymax)/2;
	yResolution = (tp_ymax - tp_ymin);

}
	
void COC_Trackpad::Pinnacle_Init()
{
  Pinnacle_ClearFlags();
  // Host configures bits of registers 0x03 and 0x05
  pRAP->Write(0x03, SYSCONFIG_1);
  pRAP->Write(0x05, FEEDCONFIG_2);

  // Host enables preferred output mode (absolute)
  pRAP->Write(0x04, FEEDCONFIG_1+FDC_YINVERT);

  // Host sets z-idle packet count to 5 (default is 30)
  pRAP->Write(0x0A, Z_IDLE_COUNT);

  // These functions are required for use with thick overlays (curved)
  setAdcAttenuation(ADC_ATTENUATE_2X);
  return;
  tuneEdgeSensitivity();
  Pinnacle_EnableFeed(true);
  
} // Pinnacle_Init

	
 // Adjusts the feedback in the ADC, effectively attenuating the finger signal
// By default, the the signal is maximally attenuated (ADC_ATTENUATE_4X for use with thin, flat overlays
void COC_Trackpad::setAdcAttenuation(uint8_t adcGain)
{
  uint8_t temp = 0x00;
  return;
  pRAP->ERA_ReadBytes(0x0187, &temp, 1);
  temp &= 0x3F; // clear top two bits
  temp |= adcGain;
  pRAP->ERA_WriteByte(0x0187, temp);
  //pRAP->ERA_ReadBytes(0x0187, &temp, 1);
/*  switch(temp)
  {
    case ADC_ATTENUATE_1X:
      Serial.println(" (X/1)");
      break;
    case ADC_ATTENUATE_2X:
      Serial.println(" (X/2)");
      break;
    case ADC_ATTENUATE_3X:
      Serial.println(" (X/3)");
      break;
    case ADC_ATTENUATE_4X:
      Serial.println(" (X/4)");
      break;
    default:
      break;      
  }
  */
}

// Changes thresholds to improve detection of fingers
void COC_Trackpad::tuneEdgeSensitivity()
{
//  uint8_t temp = 0x00; 
  
//  pRAP->ERA_ReadBytes(0x0149, &temp, 1);
  pRAP->ERA_WriteByte(0x0149,  0x04);
//  pRAP->ERA_ReadBytes(0x0149, &temp, 1);
  
//  pRAP->ERA_ReadBytes(0x0168, &temp, 1);
  pRAP->ERA_WriteByte(0x0168,  0x03);
//  pRAP->ERA_ReadBytes(0x0168, &temp, 1);
}

// Clears Status1 register flags (SW_CC and SW_DR)
void COC_Trackpad::Pinnacle_ClearFlags()
{
  pRAP->Write(0x02, 0x00);
  delayMicroseconds(50);
}

// Reads XYZ data from Pinnacle registers 0x14 through 0x17
// Stores result in absData_t struct with xValue, yValue, and zValue members
void COC_Trackpad::Pinnacle_GetAbsolute(absData_t * result)
{
  byte data[4] = { 0,0,0,0 };
  pRAP->ReadBytes(0x14, data, 4);
  Pinnacle_ClearFlags();
  
  result->xValue = data[0] | ((data[2] & 0x0F) << 8);
  result->yValue = data[1] | ((data[2] & 0xF0) << 4);
  result->zValue = data[3] & 0x3F;

  Pinnacle_CheckValidTouch(result);     // Checks for "hover" caused by curved overlays

  result->touchDown = result->xValue != 0;
  
  ClipCoordinates(result);
  if (scale_en)
  {
	  ScaleData(result);
  }
}


  /***************************************************
   * RAP functions
   **************************************************/
  void COC_Trackpad::ReadBytes(byte address, byte * data, byte count)
  {
	pRAP->ReadBytes(address, data, count);
  }
  void COC_Trackpad::Write(byte addr, byte data)
  {
	  pRAP->Write(addr, data);
  }

// Checks touch data to see if it is a z-idle packet (all zeros)
bool COC_Trackpad::zIdlePacket(absData_t * data)
{
  return data->xValue == 0 && data->yValue == 0 && data->zValue == 0;
}

// This function identifies when a finger is "hovering" so your system can choose to ignore them.
// Explanation: Consider the response of the sensor to be flat across it's area. The Z-sensitivity of the sensor projects this area 
// a short distance upwards above the surface of the sensor. Imagine it is a solid cylinder (wider than it is tall)
// in which a finger can be detected and tracked. Adding a curved overlay will cause a user's finger to dip deeper in the middle, and higher
// on the perimeter. If the sensitivity is tuned such that the sensing area projects to the highest part of the overlay, the lowest 
// point will likely have excessive sensitivity. This means the sensor can detect a finger that isn't actually contacting the overlay in the shallower area.
// ZVALUE_MAP[][] stores a lookup table in which you can define the Z-value and XY position that is considered "hovering". Experimentation/tuning is required.
// NOTE: Z-value output decreases to 0 as you move your finger away from the sensor, and it's maximum value is 0x63 (6-bits).
void COC_Trackpad::Pinnacle_CheckValidTouch(absData_t * touchData)
{ 
  uint32_t zone_x, zone_y;
  //eliminate hovering
  zone_x = touchData->xValue / ZONESCALE;
  zone_y = touchData->yValue / ZONESCALE;
  touchData->hovering = !(touchData->zValue > ZVALUE_MAP[zone_y][zone_x]);
}

// Reads Buttons from register 0x12
// Stores result in button_t struct
void COC_Trackpad::Pinnacle_GetButtons(buttons_t * btns)
{
  byte data;
  pRAP->ReadBytes(0x12, &data, 1);
  
  Pinnacle_ClearFlags();
  
  btns->left = (data & 0x04);
  btns->middle = (data & 0x02);
  btns->right = (data & 0x01);
}

// Enables/Disables the feed
void COC_Trackpad::Pinnacle_EnableFeed(bool feedEnable)
{
  uint8_t temp;

  pRAP->ReadBytes(0x04, &temp, 1);  // Store contents of FeedConfig1 register
  
  if(feedEnable)
  {
    temp |= 0x01;                 // Set Feed Enable bit
    pRAP->Write(0x04, temp);
  }
  else
  {
    temp &= ~0x01;                // Clear Feed Enable bit
    pRAP->Write(0x04, temp);
  }
}


/************* Logical Scaling Functions *************/
// Clips raw coordinates to "reachable" window of sensor
// NOTE: values outside this window can only appear as a result of noise
void COC_Trackpad::ClipCoordinates(absData_t * coordinates)
{
  if(coordinates->xValue < PINNACLE_X_LOWER)
  {
    coordinates->xValue = PINNACLE_X_LOWER;
  }
  else if(coordinates->xValue > PINNACLE_X_UPPER)
  {
    coordinates->xValue = PINNACLE_X_UPPER;
  }
  if(coordinates->yValue < PINNACLE_Y_LOWER)
  {
    coordinates->yValue = PINNACLE_Y_LOWER;
  }
  else if(coordinates->yValue > PINNACLE_Y_UPPER)
  {
    coordinates->yValue = PINNACLE_Y_UPPER;
  }
}

 void COC_Trackpad::SetScale(bool _scale_en, int16_t _xmin, int16_t _xmax, int16_t _ymin, int16_t _ymax)
 {
	 scale_en = _scale_en;
	 tp_xmin = _xmin;
	 tp_xmax = _xmax;
	 tp_ymin = _ymin;
	 tp_ymax = _ymax;
	 tp_xmid = (_xmin+_xmax)/2;
	 tp_ymid = (_ymin+_ymax)/2;
	 xResolution = tp_xmax-tp_xmin;
     yResolution = tp_ymax-tp_ymin;
 }
 
// Scales data to desired X & Y resolution
void COC_Trackpad::ScaleData(absData_t * coordinates)
{
  int32_t xTemp = 0;
  int32_t yTemp = 0;

  xTemp = coordinates->xValue;
  yTemp = coordinates->yValue;
  
  // translate coordinates to (0, 0) reference by subtracting edge-offset
  xTemp -= PINNACLE_X_MID;
  yTemp -= PINNACLE_Y_MID;

  // scale coordinates to (xResolution, yResolution) range
  coordinates->xValue = (int16_t)( ((xTemp * xResolution) / PINNACLE_X_RANGE) + tp_xmid);
  coordinates->yValue = (int16_t)( ((yTemp * yResolution) / PINNACLE_Y_RANGE) + tp_ymid);
}

/******************************************************
 * End Curved overlay Trackpad class functions
 *****************************************************/


