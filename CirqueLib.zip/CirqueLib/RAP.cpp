/***************************************************************
 * RAP (Register Access Protocol) library functions
 * Written by David Willis
 *
 * Code is built for the Cirque Trackpad Development kit
 * with Pinnacle TM040040 and TM035035 using Arduino Teensy 3.2
 *
 * However, with minor modifications (pin numbers, etc)
 * it can work with any Cirque Pinnacle based device 
 * using SPI or I2C on other Arduino-based systems.
 *
 * Supports I2C or SPI communication. 
 * 	  To determine how your touch pad is configured check if 
 *    there is a 470K resistor between pins 24 & 25 
 *			for I2C-mode, make sure that R1 is NOT populated
 *			for SPI a 470 ohm resistor should be installed
 *
 *  Arduino Hardware Interface
 *  GND,  +3.3V
 *  SDA = Pin 18  (there MUST be a pull-up to 3.3V on this signal; 
 *		4.7k recommended)
 *  SCL = Pin 19  (there MUST be a pull-up to 3.3V on this signal;
 *		4.7k recommended)
 *	For other pins, see RAP.h
 ***************************************************************/

#include "RAP.h"

/*****************************************
 * RAP class methods
 *****************************************/
 
  RAP_::RAP_()
  {
	 _mode = 0;
  } 

  RAP_::RAP_(int mode)
  {
	 _mode = mode;
  } 

  RAP_::RAP_(int dr_pin, int scl_pin, int sda_pin) // I2C version
  {
	_mode = I2C_0;
   _dr_pin = dr_pin;	
  }
  
//  RAP_(int dr_pin, int sck_pin, mosi_pin, int miso_pin, it ss_pin) //SPI version
//  {
//	  
//  }
  
  void RAP_::Write(byte addr, byte data)
  {    
  } // end Write
  
  void RAP_::ReadBytes(byte address, byte * data, byte count)
  { 
  } // end ReadBytes

  bool RAP_::DR_Asserted()
  {
	return digitalRead(_dr_pin);
  }
/****************** END BASE CLASS ***********************/

  /*****************************************
 * I2C RAP Protocol class methods
 *
 *****************************************/
  
  RAP_I2C::RAP_I2C(int mode) : RAP_(mode)
  {
	  switch (mode)
	  {
		case I2C_0:
			_dr_pin = DR0_PIN;
		break;
#ifdef TEENSY		
		case I2C_1:
			_dr_pin = DR1_PIN;
		break;
#endif
		default: _dr_pin = DR0_PIN;
		break;
	  } // end switch
	pinMode(_dr_pin, INPUT);
    // Set up I2C peripheral
    Wire.begin();
//    Wire.setClock(100000);  
  }  // constructor

  RAP_I2C::RAP_I2C(int dr_pin, int scl_pin, int sda_pin) : RAP_(dr_pin, scl_pin, sda_pin)
  {
    _sda_pin = sda_pin;
    _scl_pin = scl_pin;
	_dr_pin = dr_pin;
	pinMode(_dr_pin, INPUT);
    // Set up I2C peripheral
    Wire.begin(_sda_pin, _scl_pin);
    //Wire.setClock(100000);  
	//Serial.println("Starting I2C with SDA=" + String(sda_pin));
  }	  
  
  void RAP_I2C::Write(byte address, byte data)
  {
  // Form the WRITE command byte
	byte cmdByte = WRITE_MASK | address; 

    Wire.beginTransmission(SLAVE_ADDR);
    Wire.write(cmdByte);
    Wire.write(data);
    Wire.endTransmission(true);   
  } // end RAP_SPI write
   
  void RAP_I2C::ReadBytes(byte address, byte * data, byte count)
  {
  // Form the READ command byte
    byte cmdByte = READ_MASK | address;
    byte i = 0;

    Wire.beginTransmission(SLAVE_ADDR);
    Wire.write(cmdByte);
    Wire.endTransmission(true);

    Wire.requestFrom((byte)SLAVE_ADDR, count, (byte)true);
    while(Wire.available())
    {
      data[i++] = Wire.read();
    }
//	Serial.println("Read " + String(i) + " bytes ");
   } // ReadBytes
/****************END I2C RAP *************************/
  
  
/*****************************************
 * SPI RAP Protocol class methods
 *
 *****************************************/
  
  RAP_SPI::RAP_SPI(int mode) : RAP_(mode)
  {
	  switch (mode)
	  {
		case SPI_0:
			_dr_pin = DR0_PIN;
			_cs_pin = CS0_PIN;
		break;
#ifdef TEENSY
		case SPI_1:
			_dr_pin = DR1_PIN;
			_cs_pin = CS1_PIN;
		break;
#endif
		default:
			_dr_pin = DR0_PIN;
			_cs_pin = CS0_PIN;
		break;
	  
	  } // end switch
	pinMode(_cs_pin, OUTPUT);
	pinMode(_dr_pin, INPUT);
 	DeAssert_CS();
	
#ifdef ESP8266
	SPI.pins(SCK_PIN, DIN_PIN, DOUT_PIN, CS0_PIN);
	SPI.begin();
	SPI.setHwCs(false);
#else
	SPI.begin();
#endif

	  
  }  // constructor

  RAP_SPI::RAP_SPI(int dr_pin, int cs_pin)
  {
	_dr_pin = dr_pin;
	_cs_pin = cs_pin;
	pinMode(_cs_pin, OUTPUT);
	pinMode(_dr_pin, INPUT);
 	DeAssert_CS();
	SPI.begin();
	  
  }  // constructor

    RAP_SPI::RAP_SPI(int dr_pin, int ss_pin, int clk_pin, int din_pin, int dout_pin)
  {
	_dr_pin = dr_pin;
	_cs_pin = ss_pin;
	pinMode(_cs_pin, OUTPUT);
	pinMode(_dr_pin, INPUT);
 	DeAssert_CS();
	SPI.begin();
	  
  }  // constructor

  
  void RAP_SPI::Write(byte address, byte data)
  {
  // Form the WRITE command byte
	byte cmdByte = WRITE_MASK | address; 

	SPI.beginTransaction(
       SPISettings(10000000, MSBFIRST, SPI_MODE1));

	Assert_CS();
	SPI.transfer(cmdByte);
	SPI.transfer(data); 
	DeAssert_CS();
	SPI.endTransaction();
	   
   } // end RAP_SPI write
   
   void RAP_SPI::ReadBytes(byte address, byte * data, byte count)
   {
   // Form the READ command byte
	byte cmdByte = READ_MASK | address; 

	SPI.beginTransaction(
           SPISettings(10000000, MSBFIRST, SPI_MODE1));
  
	Assert_CS();
	SPI.transfer(cmdByte);
	SPI.transfer(0xFC); 
	SPI.transfer(0xFC); 
	for(byte i = 0; i < count; i++)
	{
		data[i] =  SPI.transfer(0xFC);
	}
	DeAssert_CS();
	SPI.endTransaction();   
   }
  
  void RAP_SPI::Assert_CS()
  {
	digitalWrite(_cs_pin, LOW);
  }
	  
  void RAP_SPI::DeAssert_CS()
  {
	digitalWrite(_cs_pin, HIGH);
  }
/**************** END RAP_SPI **************************/


/*  ERA (Extended Register Access) Functions  */
// Reads <count> bytes from an extended register at <address> (16-bit address),
// stores values in <*data>
void RAP_::ERA_ReadBytes(uint16_t address, uint8_t * data, uint16_t count)
{  
  uint8_t ERAControlValue = 0xFF;

  EnableFeed(false); // Disable feed

  Write(0x1C, (uint8_t)(address >> 8));     // Send upper byte of ERA address
  Write(0x1D, (uint8_t)(address & 0x00FF)); // Send lower byte of ERA address
  
  for(uint16_t i = 0; i < count; i++)
  {
    Write(0x1E, 0x05);  // Signal ERA-read (auto-increment) to Pinnacle
    
    // Wait for status register 0x1E to clear
    do
    {
      ReadBytes(0x1E, &ERAControlValue, 1);
    } while(ERAControlValue != 0x00);
    
    ReadBytes(0x1B, data + i, 1);
  }
  Write(0x02, 0x00); // ERA sets the flag. Clear it
}

// Writes a byte, <data>, to an extended register at <address> (16-bit address)
void RAP_::ERA_WriteByte(uint16_t address, uint8_t data)
{
  uint8_t ERAControlValue = 0xFF;

  EnableFeed(false); // Disable feed

  Write(0x1B, data);      // Send data byte to be written
  
  Write(0x1C, (uint8_t)(address >> 8));     // Upper byte of ERA address
  Write(0x1D, (uint8_t)(address & 0x00FF)); // Lower byte of ERA address

  Write(0x1E, 0x02);  // Signal an ERA-write to Pinnacle

  // Wait for status register 0x1E to clear
  do
  {
    ReadBytes(0x1E, &ERAControlValue, 1);
  } while(ERAControlValue != 0x00);
    
  Write(0x02, 0x00); // ERA sets the flag. Clear it
}

// Enables/Disables the feed, read modify write
void RAP_::EnableFeed(bool feedEnable)
{
  uint8_t temp;

  ReadBytes(0x04, &temp, 1);  // Store contents of FeedConfig1 register
  if(feedEnable)
  {
    temp |= 0x01;                 // Set Feed Enable bit
    Write(0x04, temp);
  }
  else
  {
    temp &= ~0x01;                // Clear Feed Enable bit
    Write(0x04, temp);
  }
}