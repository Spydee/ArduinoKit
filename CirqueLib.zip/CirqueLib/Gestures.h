#ifndef GESTURES_H
#define GESTURES_H

#include <Location.h>

// include to get data definitions
#include <Cirque_Structs.h>
//#include <RAP.h>
//#include <Cirque_Trackpad.h>
//#include <Curved_Overlay.h>


enum GESTURES_ { 
	NONE,
	ROTATE_RIGHT,
	ROTATE_LEFT,
	SWIPE_RIGHT,
	SWIPE_LEFT,
	SWIPE_UP,
	SWIPE_DOWN,
	TAP
};

enum gState_ {
	IDLE,
	DRAWING,
	LAST_TOUCH
};
	
#define PATHLENGTH 100
	
class Gestures
{
	public:
	Gestures();
	Gestures(bool _reset);
	Gestures(int16_t xmin, int16_t xmax, int16_t ymin, int16_t ymax);
	
	GESTURES_ getGesture();
	bool processData(absData_t touch);
	int update(absData_t touchData);

	fLocationR getCurrentLocation();
	double getdXdt();
	double getdYdt();
	double getW();
	double getdPh();
	long   getTouchTime();
	
	//bool prevTouch = false;
	//bool firstTouch(bool newTouch);

	fLocation path[PATHLENGTH];	// location history to determine swipe, etc.
	int pathIndex = 0;
	int touchCount = 0;
	
	fLocation locFirstTouch;	// where the finger first touched at the start of a gesture
	fLocationR dummy;
	fLocation locLastTouch;		// where the finger is currently located or, if finger lifted, the 
								// last touched location
	double avgdX;				// average derivative in X direction
	double avgdY;				// average derivative in Y direction
	double avgdW;				// average derivative in W direction (around the circle)
	long timeFirstTouch;
	long timeLastTouch;
	long deltaTimeTouch;
	long rotateTime;
	long timeTouchElapsed;
	
	private:
	bool firstTouch = false;
	gState_ state = IDLE;
	void init();
	void reset();
	void filterData();
	int16_t checkForGesture();
		
	int ptr;
	int16_t g_xmin;
	int16_t g_xmax;
	int16_t g_xrange;
	int16_t g_ymin;
	int16_t g_ymax;
	int16_t g_yrange;

	GESTURES_ gesture;
};

#endif