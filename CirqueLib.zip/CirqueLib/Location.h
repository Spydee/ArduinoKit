/********************************************************************
 * Location and Axis class definitions
 * Written by David Willis
 * Last updated July 24, 2018
 *******************************************************************/
#ifndef LOCATION_H
#define LOCATION_H

#include <math.h>
#define rad2deg(ph) (180.0*ph/M_PI)
#define deg2rad(ph) (M_PI*ph/180.0)

/********************************************************************
 * Location structures used by the two classes
 * fLocationR is floating point Location for rectangle coordinates
 * fLocationP is polar coordinates
 * fLocation has both
 *******************************************************************/

typedef struct _frloc {
  double x;
  double y;
} fLocationR;

typedef struct _fploc {
  double mag;
  double ph; // phase
} fLocationP;

typedef struct _floc {
//  float x;
//  float y;
//  float mag;
//  float ph; // phase
  fLocationR XY;
  fLocationP MP;
} fLocation;

/********************************************************************
 * This class converts a current point to a new axis
 * Rotation of the axis is CCW for a positive angle
 * The point is stationary, the axis is what is rotated.
 * A point p1 = (1,0) (mag, ph) becomes
 * p2 = rotate(p1, pi/4) results in p2 = (1,-pi/4)
 * 
 * Translation of the axis, is moving the origin to (dx, dy).
 * For instance, pick the point p1 = (1,2) (x,y). This same point
 * for a translated axis with origin at (2,1) becomes (-1,1)
 * Thus p2 = translate(p1, 2, 1) results in p2 = (-1,1)
 *******************************************************************/
class Axis
{
  public:

  static fLocation rotate(fLocation cur, double rad);
  static fLocationR rotate(fLocationR cur, double rad);
  static fLocationP rotate(fLocationP cur, double rad);
  static fLocation translate(fLocation cur, double dx, double dy);
  static fLocationR translate(fLocationR cur, double dx, double dy);
  static fLocationP translate(fLocationP cur, double dx, double dy);
  static fLocationP toPolarf(fLocationR loc);
  static fLocationR toRectf(fLocationP loc);

};


class Location {
    public:
    fLocationR loc;
	fLocationP magph;
	fLocationR prev_loc;
    fLocationR offset;
    Location();
    Location(float _x, float _y);
    Location(float _x, float _y, float _offX, float _offY);
	void update(int _newX, int _newY);
//	void Update(_absData loc);
	fLocationR getXY();
	fLocationP getMagPhase();
	float deltaPhase();
	fLocationR deltaLoc();
};

#endif