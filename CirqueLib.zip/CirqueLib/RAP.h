#ifndef RAP_H
#define RAP_H

#include <SPI.h>	// for SPI mode
#include <Wire.h>	// for I2C mode

#define ESP8266
#include "CirqueDefs.h"

// define an abstract protocol class
class RAP_ {

public:
  int _mode = SPI_0;
  int _dr_pin = DR0_PIN;
  
  RAP_();
  RAP_(int mode);
//  RAP_(int dr_pin, int ss_pin);
  RAP_(int dr_pin, int scl_pin, int sda_pin); // I2C version
//  RAP_(int dr_pin, int ss_pin, int clk_pin, int din_pin, int dout_pin);
  
  virtual void Write(byte addr, byte data);
  virtual void ReadBytes(byte address, byte * data, byte count);

  bool DR_Asserted();
  void ERA_WriteByte(uint16_t address, uint8_t data);
  void ERA_ReadBytes(uint16_t address, uint8_t * data, uint16_t count);
  void EnableFeed(bool);
  
}; // end protocol

class RAP_I2C : public RAP_ {

public:
  RAP_I2C(int mode);
  RAP_I2C(int dr_pin, int scl_pin, int sda_pin);
  virtual void Write(byte addr, byte data);
  virtual void ReadBytes(byte address, byte * data, byte count);

  private:
  int _sda_pin;
  int _scl_pin;
  int _drpin;

  
}; // end RAP_SPI

class RAP_SPI : public RAP_ {

public:
  int _cs_pin = CS0_PIN;

  RAP_SPI(int mode);
  RAP_SPI(int dr_pin, int cs_pin);
  RAP_SPI(int dr_pin, int cs_pin, int clk_pin, int din_pin, int dout_pin);
  virtual void Write(byte addr, byte data);
  virtual void ReadBytes(byte address, byte * data, byte count);
  void Assert_CS();
  void DeAssert_CS();
  
}; // end RAP_SPI


#endif