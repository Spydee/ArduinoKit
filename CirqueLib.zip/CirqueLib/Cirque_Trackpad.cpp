/***************************************************************
 * Cirque_Trackpad TMxx Circular Track Pad library and class structure
 * Written by David Willis
 *
 * Supports Cirque TM040040 and TM035035 track pads
 
 * code is built to work with a Teensy 3.1/3.2 but it can easily be adapted to
 * work with Arduino-based systems.

 * Supports I2C or SPI communication. 
 * 	  To determine how your touch pad is configured check if R1 (or the resistor 
 *    that connects pins 24 & 25 * of the 1CA027 IC) is installed
 *			for I2C-comport, make sure that R1 is NOT populated
 *			for SPI a 470 ohm resistor should be installed
 
 *  Pinnacle TM040040 with Arduino
 *  Hardware Interface
 *  GND
 *  +3.3V
 *  SDA = Pin 18  (there MUST be a pull-up to 3.3V on this signal; 4.7k recommended)
 *  SCL = Pin 19  (there MUST be a pull-up to 3.3V on this signal; 4.7k recommended)
 *  DR = Pin 9

// The pad is configured for Absolute mode tracking.  Touch data is sent in text format over USB CDC to
// the host PC.  You can open a terminal window on the PC to the USB CDC port and see X, Y, and Z data
// scroll up the window when you touch the sensor. Tools->Serial Monitor can be used to view touch data.

***************************************************************/

#include "Cirque_Trackpad.h"

/*****************************************************
 * Trackpad class functions
 *****************************************************/

/**************** Constructors ***********************/
// comport is SPI_0, SPI_1, I2C_0 or I2C_1
	Cirque_Trackpad::Cirque_Trackpad(int _comport)
	{
	  switch (_comport) {
	  case SPI_0:
	  case SPI_1:	pRAP = new RAP_SPI(_comport);
	  break;
	  case I2C_0:
	  case I2C_1:	pRAP = new RAP_I2C(_comport);
	  break;
	  default:		pRAP = new RAP_SPI(SPI_0);
	  break;
	  } // switch
	  Pinnacle_Init();
	} // constructor

	Cirque_Trackpad::Cirque_Trackpad(RAP_ *pR)
	{
		pRAP = pR;
		Pinnacle_Init();
	}

/************ Pinnacle-based TM0XX0XX Functions ******/

void Cirque_Trackpad::Pinnacle_Init()
{
  Pinnacle_ClearFlags();
  // Host configures bits of registers 0x03 and 0x05
  pRAP->Write(0x03, SYSCONFIG_1);
  pRAP->Write(0x05, FEEDCONFIG_2);

  // Host enables preferred output mode (absolute)
  pRAP->Write(0x04, FEEDCONFIG_1);

  // Host sets z-idle packet count to 5 (default is 30)
  pRAP->Write(0x0A, Z_IDLE_COUNT);
  Serial.println("Trackpad Pinnacle_Init");
  
} // Pinnacle_Init

// Clears Status1 register flags (SW_CC and SW_DR)
void Cirque_Trackpad::Pinnacle_ClearFlags()
{
  pRAP->Write(0x02, 0x00);
  delayMicroseconds(50);
}

// Reads XYZ data from Pinnacle registers 0x14 through 0x17
// Stores result in absData_t struct with xValue, yValue, and zValue members
void Cirque_Trackpad::Pinnacle_GetAbsolute(absData_t * result)
{
  byte data[4] = { 0,0,0,0 };
  pRAP->ReadBytes(0x14, data, 4);
  
  Pinnacle_ClearFlags();
  
  result->xValue = data[0] | ((data[2] & 0x0F) << 8);
  result->yValue = data[1] | ((data[2] & 0xF0) << 4);
  result->zValue = data[3] & 0x3F;

  result->touchDown = result->xValue != 0;

  //ClipCoordinates(result);
  if (scale_en)
  {
	  ScaleData(result);
  }
}

// Reads Buttons from register 0x12
// Stores result in button_t struct
void Cirque_Trackpad::Pinnacle_GetButtons(buttons_t * btns)
{
  byte data;
  pRAP->ReadBytes(0x12, &data, 1);
  
  Pinnacle_ClearFlags();
  
  btns->left = (data & 0x04);
  btns->middle = (data & 0x02);
  btns->right = (data & 0x01);
}
  void Pinnacle_GetAbsolute(absData_t * result, buttons_t * btns);
  void Pinnacle_GetRelative(relData_t * result);

// Checks touch data to see if it is a z-idle packet (all zeros)
bool Cirque_Trackpad::Pinnacle_zIdlePacket(absData_t * data)
{
  return data->xValue == 0 && data->yValue == 0 && data->zValue == 0;
}

  /***************************************************
   * RAP functions
   **************************************************/
  void Cirque_Trackpad::ReadBytes(byte address, byte * data, byte count)
  {
	pRAP->ReadBytes(address, data, count);
  }
  void Cirque_Trackpad::Write(byte addr, byte data)
  {
	  pRAP->Write(addr, data);
  }


  /***************************************************
   * Private functions
   **************************************************/
   
  // Enables/Disables the feed
void Cirque_Trackpad::Pinnacle_EnableFeed(bool feedEnable)
{
  uint8_t temp;

  pRAP->ReadBytes(0x04, &temp, 1);  // Store contents of FeedConfig1 register
  
  if(feedEnable)
  {
    temp |= 0x01;                 // Set Feed Enable bit
    pRAP->Write(0x04, temp);
  }
  else
  {
    temp &= ~0x01;                // Clear Feed Enable bit
    pRAP->Write(0x04, temp);
  }
}


/************* Logical Scaling Functions *************/
// Clips raw coordinates to "reachable" window of sensor
// NOTE: values outside this window can only appear as a result of noise
void Cirque_Trackpad::ClipCoordinates(absData_t * coordinates)
{
  if(coordinates->xValue < PINNACLE_X_LOWER)
  {
    coordinates->xValue = PINNACLE_X_LOWER;
  }
  else if(coordinates->xValue > PINNACLE_X_UPPER)
  {
    coordinates->xValue = PINNACLE_X_UPPER;
  }
  if(coordinates->yValue < PINNACLE_Y_LOWER)
  {
    coordinates->yValue = PINNACLE_Y_LOWER;
  }
  else if(coordinates->yValue > PINNACLE_Y_UPPER)
  {
    coordinates->yValue = PINNACLE_Y_UPPER;
  }
}

 void Cirque_Trackpad::SetScale(bool _scale_en, int16_t _xmin, int16_t _xmax, int16_t _ymin, int16_t _ymax)
 {
	 scale_en = _scale_en;
	 xmin = _xmin;
	 xmax = _xmax;
	 ymin = _ymin;
	 ymax = _ymax;
 }
 
// Scales data to desired X & Y resolution
void Cirque_Trackpad::ScaleData(absData_t * coordinates)
{
  int32_t xTemp = 0;
  int32_t yTemp = 0;
  int16_t xResolution = xmax-xmin;
  int16_t yResolution = ymax-ymin;

  xTemp = coordinates->xValue;
  yTemp = coordinates->yValue;
  
  // translate coordinates to (0, 0) reference by subtracting edge-offset
  xTemp -= PINNACLE_X_LOWER;
  yTemp -= PINNACLE_Y_LOWER;

  // scale coordinates to (xResolution, yResolution) range
  coordinates->xValue = (int16_t)(xTemp * xResolution / PINNACLE_X_RANGE + xmin);
  coordinates->yValue = (int16_t)(yTemp * yResolution / PINNACLE_Y_RANGE + ymin);
}

/******************************************************
 * End Trackpad class functions
 *****************************************************/
